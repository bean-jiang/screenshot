<template>
    <dashBoard></dashBoard>
    <TresCanvas clearColor="#999" window-size >
        <TresPerspectiveCamera ref="navCamera"
        :position="[0, 80, 160]" :fov="6" :near="0.1" :far="1000" :look-at="[0, -5, 0]" />
        <OrbitControls enableDamping />
        <TresAmbientLight :intensity="2.0" />
        <TresDirectionalLight  :intensity="1"  />
        <Suspense>
            <model :position="[0, -5, 0]"  v-bind="fresnelState"/>
        </Suspense>
        
        <Suspense>
            <reflectorDUDV :position="[0, -5, 0]" v-bind="reflectorState" />
        </Suspense>
    </TresCanvas>


</template>

<script setup>
import { reactive, ref,watchEffect,watch } from 'vue'
import { OrbitControls } from '@tresjs/cientos'
import { Pane } from 'tweakpane'
import reflectorDUDV from '../components/fresnel-effect/components/reflectorDUDV.vue';
import model from '../components/fresnel-effect/components/model.vue';
import * as THREE from 'three'
import dashBoard from '../components/dashBoard/dashBoard.vue';

const navCamera = ref (null)

const reflectorState = reactive({
    reflectivity: 2.6,
    showGridHelper: false,
    scale: 4,
})

const fresnelState = reactive({
    lungs_glow_color:'#a5fff4',
    lungs_glow_color2:'#00ffff',

    body_glow_color:'#84ccff',
    body_glow_color2:'#84ccff',
    body_c:1.11,
    body_p:1.0,
    body_opacity:0.5,

    fault_glow_color:"#ff0000",
    fault_opacity:1.0,
    fault_c:1.6,
    fault_p:2.5,

    organ_glow_color:"#3e8bff",
    organ_emissive:2.0,
    organ_opacity:1.0,
    organ_metalness:0.3,
    organ_roughness:0.2,

    bone_glow_color:"#4292f3",
    bone_emissive:0.3,
    bone_opacity:0.3,

    neuron_glow_color:"#7efff0",
    neuron_glow_color2:"#00ffff",
    neuron_c:0.8,
    neuron_p:2.0,
    neuron_opacity:1.0,

    modelPath:"./plugins/humanMedicine/model/人体.glb",
})
// const paneControl = new Pane({
//     expanded: true,
//     title: '调节参数',
// })
// const f1 = paneControl.addFolder({
//     title: '身体参数',
//     expanded: true,
// })
// f1.addBinding(fresnelState, 'body_glow_color', { label: '颜色' })
// f1.addBinding(fresnelState, 'body_c', {
//     label: '基础反射强度',
//     min: 0.0,
//     max: 5.0,
//     step: 0.5,
// })
// f1.addBinding(fresnelState, 'body_p', {
//     label: '非线性变化',
//     min: 0.0,
//     max: 5.0,
//     step: 0.5,
// })
// f1.addBinding(fresnelState, 'body_opacity', {
//     label: '透明度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// const f2 = paneControl.addFolder({
//     title: '报警参数',
//     expanded: false,
// })

// f2.addBinding(fresnelState, 'fault_glow_color', { label: '颜色' })
// f2.addBinding(fresnelState, 'fault_c', {
//     label: '基础反射强度',
//     min: 0.0,
//     max: 5.0,
//     step: 0.5,
// })
// f2.addBinding(fresnelState, 'fault_p', {
//     label: '非线性变化',
//     min: 0.0,
//     max: 5.0,
//     step: 0.5,
// })
// f2.addBinding(fresnelState, 'fault_opacity', {
//     label: '透明度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// const f3 = paneControl.addFolder({
//     title: '器官参数',
//     expanded: false,
// })
// f3.addBinding(fresnelState, 'organ_glow_color', { label: '颜色' })
// f3.addBinding(fresnelState, 'organ_roughness', {
//     label: '粗糙度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// f3.addBinding(fresnelState, 'organ_metalness', {
//     label: '金属度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// f3.addBinding(fresnelState, 'organ_opacity', {
//     label: '透明度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// const f4 = paneControl.addFolder({
//     title: '骨头参数',
//     expanded: false,
// })
// f4.addBinding(fresnelState, 'bone_glow_color', { label: '颜色' })
// f4.addBinding(fresnelState, 'bone_opacity', {
//     label: '自发光',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// f4.addBinding(fresnelState, 'bone_opacity', {
//     label: '透明度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// const f5 = paneControl.addFolder({
//     title: '神经参数',
//     expanded: false,
// })
// f5.addBinding(fresnelState, 'neuron_glow_color', { label: '颜色1' })
// f5.addBinding(fresnelState, 'neuron_glow_color2', { label: '颜色2' })
// f5.addBinding(fresnelState, 'neuron_c', {
//     label: '基础反射强度',
//     min: 0.0,
//     max: 2.0,
//     step: 0.1,
// })
// f5.addBinding(fresnelState, 'neuron_p', {
//     label: '非线性变化',
//     min: 0.0,
//     max: 5.0,
//     step: 0.5,
// })
// f5.addBinding(fresnelState, 'neuron_opacity', {
//     label: '透明度',
//     min: 0.0,
//     max: 1.0,
//     step: 0.1,
// })
// const f6 = paneControl.addFolder({
//     title: '模型切换',
//     expanded: false,
// })
// f6.addBinding(fresnelState, 'modelPath', { 

//   label: '模型',
//   options: {
//     肺: './model/fei.glb',
//     外表: './model/外表.glb',
//     人体: './model/人体.glb',
//     神经: './model/神经.glb',
//     骨头: './model/骨头.glb',
//   }

// });

</script>

<style scoped>


</style>
