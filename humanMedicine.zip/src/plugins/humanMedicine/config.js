export default {
    "name": "humanMedicine",
    "title": "人体医疗可视化",
    "intro": `基于TVT.js的人体健康检测, 人体器官模型展示,可用于医疗行业快速落地，插件包含调试界面和UI大屏界面。<br>
    1.插件表格组件依赖：highcharts库和@arco-design/web-vue库<br>
    2.插件模型可随意切换，且使用了菲涅尔效果，参数可调<br>
    具体插件详见:
    <a style="color:#5384ff;" href="https://www.icegl.cn/tvtstore/humanMedicine" target="_blank">人体医疗可视化</a>`,
    "version": "1.0.1",
    "author": "Kanz",
    "website": "站点地址",
    "state": "active",
    "creatTime": "2025-02-04",
    "updateTime": "2025-02-04",
    "require": [],
    "tvtstore": 'LISENCE',
    "preview": [
        {
        "src": "plugins/humanMedicine/preview/缩略图.png",
        "type": "img",
        "name": "humanMedicine",
        "title": "UI大屏界面",
        disableFPSGraph: true,
        disableSrcBtn: true
        }, 
        {
        "src": "plugins/humanMedicine/preview/缩略图1.png",
        "type": "img",
        "name": "humanMedicineTest",
        "title": "模型调试界面",
        disableFPSGraph: false,
        disableSrcBtn: true
        }, 
    ]
}