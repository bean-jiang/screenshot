uniform float time;
varying vec2 vUv;
uniform vec3 glow_color;
uniform vec3 glow_color2;
varying float intensity;
varying vec3 vPosition;
void main() {
// 生成一个随时间变化的闪烁因子，范围在0到1之间
  // float flickerFactor = abs(sin(time * 25.0)) * 0.5 + 0.5; // 3.0是闪烁频率，可以根据需要调整

  vec3 glow = glow_color * intensity;
  vec3 glow2 = glow_color2 * intensity;
  vec3 glow3 = mix(glow, glow2, intensity);
  
  //   // 应用闪烁因子
  // glow3 *= flickerFactor;

  float light = 0.0;
  float now = smoothstep(0.0, 0.3, fract(time));
  float alpha = mod((vUv.y - now) * 1.0, 1.0);

  if (-0.005 < now - vUv.y && now - vUv.y < 0.005) {
    if (now == 1.0) {
      light = 0.0;
    } else {
      light += 0.5;
    }
  }
  gl_FragColor = vec4(glow3 + light, alpha);
}