import fresnelFragmentShader from '../shaders/fresnelFragmentShader.frag'
import fresnelVertexShader from '../shaders/fresnelVertexShader.vert'
import * as THREE from 'three';
import xRayVertex from '../shaders/xRay.vert'
import xRayFrag from '../shaders/xRay.frag'

// 报警菲涅尔效果
export function createFaultMaterial(props,texture) {
  return new THREE.ShaderMaterial({
    uniforms: {
        c: { type: 'f', value: props.fault_c },
        p: { type: 'f', value: props.fault_p },
        glowColor: { type: 'c', value: new THREE.Color(props.fault_glow_color) },
        lightningTexture: { type: 't', value: texture.map },
        offsetY: { type: 'f', value: Math.sin(5.0) },
        uTime: { type: 'f', value: 0.0 },
        uOpacity: { type: 'f', value: props.fault_opacity },
      },
      vertexShader: xRayVertex,
      fragmentShader: xRayFrag,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
}
// 身体菲涅尔效果
export function createBodyMaterial(props,texture) {
  return new THREE.ShaderMaterial({
    uniforms: {
        c: { type: 'f', value: props.body_c },
        p: { type: 'f', value: props.body_p },
        glowColor: { type: 'c', value: new THREE.Color(props.body_glow_color) },
        lightningTexture: { type: 't', value: texture.map },
        offsetY: { type: 'f', value: Math.sin(5.0) },
        uTime: { type: 'f', value: 0.0 },
        uOpacity: { type: 'f', value: props.body_opacity },
      },
      vertexShader: xRayVertex,
      fragmentShader: xRayFrag,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
}
// 肺部菲涅尔效果
export function createLungsFresnelMaterial(camera, props) {
  return new THREE.ShaderMaterial({
    uniforms: {
      view_vector: { type: 'v3', value: camera.value.position },
      c: { type: 'f', value: props.body_c },
      p: { type: 'f', value: props.body_p },
      glow_color: { type: 'v3', value: new THREE.Color(props.lungs_glow_color) },
      glow_color2: { type: 'v3', value: new THREE.Color(props.lungs_glow_color2) },
      time: { type: 'f', value: 0.0 },
    },
    transparent: true,
    opacity: props.body_opacity,
    blending: THREE.AdditiveBlending,
    depthTest: false,
    vertexShader: fresnelVertexShader,
    fragmentShader: fresnelFragmentShader,
  });
}
// 神经菲涅尔效果
export function createNeuronFresnelMaterial(camera, props) {
  return new THREE.ShaderMaterial({
    uniforms: {
      view_vector: { type: 'v3', value: camera.value.position },
      c: { type: 'f', value: props.neuron_c },
      p: { type: 'f', value: props.neuron_p },
      glow_color: { type: 'v3', value: new THREE.Color(props.neuron_glow_color) },
      glow_color2: { type: 'v3', value: new THREE.Color(props.neuron_glow_color2) },
      time: { type: 'f', value: 0.0 },
    },
    transparent: true,
    opacity: props.neuron_opacity,
    blending: THREE.AdditiveBlending,
    depthTest: false,
    vertexShader: fresnelVertexShader,
    fragmentShader: fresnelFragmentShader,
  });
}
// 骨头效果
export function createBoneMaterial(props) {
  return new THREE.MeshStandardMaterial({
    depthTest: false,
      color: new THREE.Color(props.bone_glow_color),
      transparent: true,
      opacity: props.bone_opacity,
      emissive: props.bone_emissive,
      depthWrite: false,
      // blending: THREE.AdditiveBlending,
  });
}

// 器官效果
export function createOrganFresnelMaterial(props) {
  return new THREE.MeshStandardMaterial({
    depthTest: false,
      color: new THREE.Color(props.organ_glow_color),
      transparent: true,
      opacity: props.organ_opacity,
      emissive: props.organ_emissive,
      depthWrite: false,
      roughness: props.organ_roughness,
			metalness: props.organ_metalness,
      // blending: THREE.AdditiveBlending,
  });
}
// 器官变暗效果
export function createOtherOragnMaterial(props) {
  return new THREE.MeshPhongMaterial({
    color: '#888888',
    transparent: true,
    opacity: 0.2,
  });
}
