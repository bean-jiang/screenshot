import { Plugin } from '/Users/mac/Documents/project/three/icegl-three-vue-tres-master/node_modules/@fesjs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','rootContainer','onAppCreated','render','patchRoutes','modifyCreateHistory','modifyRoute','beforeRender','onRouterCreated','access','layout','request',],
});

export { plugin };
