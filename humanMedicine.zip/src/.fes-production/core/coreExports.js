export {
    useRoute,
    useRouter,
    onBeforeRouteUpdate,
    onBeforeRouteLeave,
    RouterLink,
    RouterView,
    useLink,
    createWebHashHistory,
    createWebHistory,
    createMemoryHistory,
    createRouter,
    Plugin,
    ApplyPluginsType
} from '/Users/mac/Documents/project/three/icegl-three-vue-tres-master/node_modules/@fesjs/runtime';

export { plugin } from '../core/plugin.js';
export { getRouter, getHistory, destroyRouter, defineRouteMeta } from '../core/routes/routeExports.js';

