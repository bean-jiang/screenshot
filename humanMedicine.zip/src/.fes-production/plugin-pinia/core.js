import { createPinia } from 'pinia'
;

const pinia = createPinia();


const install = function (app) {
    app.use(pinia);
}

export {
    install,
    pinia,
};
