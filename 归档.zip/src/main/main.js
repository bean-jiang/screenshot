const { app,BrowserWindow,Tray,nativeTheme } = require("electron");
const  { runPath,tmpDir,isMac }              = require("../common/global");
const { Store }                              = require("../lib/store");
const { createContextMenu }                  = require("../config/context_menu");
const { existsSync,mkdir }                   = require("fs");
const { join }                               = require("path");
const { defaultSetting }                     = require("../config/setting");
const { showPhoto }                          = require("../common/utils");
const { ClipWindow }                         = require("../Enity/ClipWindow");
const { setMenu }                            = require("../config/menu_template");

let tray;

const portable     = "portable";
//const userDataPath = preloadConfig || (statSync(join(runPath, portable)).isDirectory() ? join(runPath, portable) : "");
const store       = new Store();
const dev         = (process.argv.includes("-d") || process.env.ESEARCH_DEV || store.get("dev")) ? true : false;

const contextMenu = createContextMenu(store,dev);
const clipWindow  = new ClipWindow(store,dev);

app.commandLine.appendSwitch(
  "enable-experimental-web-platform-features",
  "enable",
);

app.whenReady().then(() => {
  createWindow();
})

const createWindow = () => {
  //是否第一次运行，加载配置项目
  if(store.get("isFirstRun") === undefined) {
    for(const i in defaultSetting) {
      store.set(i,defaultSetting[i])
    }
  }
  
  if(isMac) {
    tray = new Tray(`${runPath}/assets/logo/macIconTemplate.png`)
  } else {
    tray = new Tray(`${runPath}/assets/logo/32x32.png`);
  }

  tray.setToolTip(app.getName());

  if(store.get("clickTrayScreenshot")) {
    tray.on("click",() => { 
      clipWindow.showPhoto();
    });
    tray.on("right-click", () => {
      tray.popUpContextMenu(contextMenu);
    });
  } else {
    tray.setContextMenu(contextMenu);
  }

  if (store.get("runTips")) {
    new Notification({
        title: app.name,
        body: `${app.name} 已经在后台启动`,
        icon: `${runPath}/assets/logo/64x64.png`,
    }).show();
  }


  // tmp目录
  if (!existsSync(tmpDir)) mkdir(tmpDir, () => { });
  if (store.get("isKeeClip")) {
    clipWindow = clipWindow.createClipWindow();
  } else {
    new BrowserWindow({ show: false });
  }

  nativeTheme.themeSource = "system";

  setMenu();
}

