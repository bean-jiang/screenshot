const { 
	app, 
} = require("electron");

const { join } = require("path");

const rendererPath = (window, fileName) => {
	if (!app.isPackaged && process.env.ELECTRON_RENDERER_URL) {
		const x = new url.URL(mainUrl(fileName));
		window.loadURL(x.toString());
	} else {
		window.loadFile(mainUrl(fileName));
	}
	
	window.webContents.on("will-navigate", (event) => {
		event.preventDefault();
	});

	window.webContents.setWindowOpenHandler(() => {
		return { action: "deny" };
	});
}

const mainUrl = (fileName) => {
	if (!app.isPackaged && process.env.ELECTRON_RENDERER_URL) {
			const mainUrl = `${process.env.ELECTRON_RENDERER_URL}/${fileName}`;
			return mainUrl;
	}
	return join(__dirname, "../renderer", fileName);
}

module.exports = {
	rendererPath
}