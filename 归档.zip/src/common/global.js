const{ join,resolve } = require("path");
const { tmpdir }      = require("os");

const runPath = join(resolve(__dirname, ""), "../../");
const tmpDir = join(tmpdir(), "screenshot");
const isMac = process.platform === "darwin";
const theIcon = process.platform === "win32" ? join(runPath, "assets/logo/icon.ico") : join(runPath, "assets/logo/1024x1024.png");

module.exports = {
    runPath,
    tmpDir,
    isMac,
    theIcon
}