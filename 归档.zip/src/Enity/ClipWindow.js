const {
	app,
	screen,
	BrowserWindow,
	dialog,
	Notification
} = require("electron");
const { readFile } = require("fs");
const { theIcon } = require("../common/global");
const { rendererPath } = require("../common/utils");

const devCSS = "[data-dev]{display:none}";

class ClipWindow {
	constructor(store, dev) {
		this.store            = store;
		this.dev              = dev;
		this.clipWindowLoaded = null;
		this.clipWindow       = null;
	}

	showPhoto = (imgPath) => {
		if (imgPath) {
			readFile(imgPath, (err, data) => {
				if (err) {
					console.error(err);
				}
				this.sendCaptureEvent(data);
			});
		} else {
			this.sendCaptureEvent();
		}
	}

	sendCaptureEvent = async (data, type) => {
		(await this.getClipWin())?.webContents.send(
			"reflash",
			screen.getAllDisplays(),
			data,
			screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).id,
			type,
		);
	}

	getClipWin = async () => {
		if (this.clipWindowLoaded && !this.clipWindow?.isDestroyed()) {
			return this.clipWindow;
		}

		if (!this.clipWindow || this.clipWindow.isDestroyed()) {
			this.clipWindow = this.createClipWindow();
		}

		return new Promise((resolve) => {
			this.clipWindow?.webContents.once("did-finish-load", () => {
				this.clipWindowLoaded = true;
				return resolve(this.clipWindow);
			})
		});
	}

	createClipWindow = () => {
		const _clipWindow = new BrowserWindow({
			icon: theIcon,
			width: screen.getPrimaryDisplay().workAreaSize.width,
			height: screen.getPrimaryDisplay().workAreaSize.height,
			show: true,
			alwaysOnTop: !this.dev,                                        // 为了方便调试，调试模式就不居上了
			fullscreenable: true,
			transparent: true,
			frame: false,
			resizable: process.platform === "linux",                     // gnome下为false时无法全屏
			skipTaskbar: true,
			autoHideMenuBar: true,
			movable: false,
			enableLargerThanScreen: true,                                             // mac
			hasShadow: false,
			webPreferences: {
				nodeIntegration: true,
				contextIsolation: false,
				zoomFactor: this.store.get("全局.缩放") || 1.0,
			},
		});

		if (!this.dev) {
			_clipWindow.webContents.insertCSS(devCSS);
			_clipWindow.setAlwaysOnTop(true, "screen-saver")
		}

		rendererPath(_clipWindow, "capture.html");

		if (this.dev) {
			_clipWindow.webContents.toggleDevTools();
		}

		_clipWindow.webContents.on("render-process-gone", (_e, d) => {
			console.log(d);
			const id = dialog.showMessageBoxSync({
				message: "截屏程序崩溃，是否重启？",
				buttons: ["重启", "退出应用"],
				defaultId: 0,
				cancelId: 1,
				detail: JSON.stringify(d),
			});
			if (id === 0) {
				this.exitFullScreen();
			}

			if (id === 1) {
				app.exit();
			}
		});

		_clipWindow.webContents.once("did-finish-load", () => {
			this.clipWindowLoaded = true;
		});

		return _clipWindow;
	}

	exitFullScreen = () => {
		if (this.store.get("isKeeClip")) {
			clipWindow?.setSimpleFullScreen(false);
			clipWindow?.hide();
			try {
				clipWindow?.reload();
			} catch {

			}
		} else {
			this.clipWindow?.close();
			this.clipWindow = null;
			this.clipWindowLoaded = false;
		}
	}
}

module.exports = {
	ClipWindow
}