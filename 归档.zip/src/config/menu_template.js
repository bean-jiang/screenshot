const { app, BrowserWindow, Menu } = require("electron");
const { isMac } = require("../common/global");

const setMenu = () => {
	const menuTemplate = [
		...(isMac
			? [
				{
					label: app.name,
					submenu: [
						{ label: `关于 ${app.name}`, role: "about" },
						{ type: "separator" },
						{
							label: "设置",
							click: () => {
								//createSettingWindow();
							},
							accelerator: "CmdOrCtrl+,",
						},
						{ type: "separator" },
						{ label: "服务", role: "services" },
						{ type: "separator" },
						{ label: `隐藏 ${app.name}`, role: "hide" },
						{ label: "隐藏其他", role: "hideOthers" },
						{ label: "全部显示", role: "unhide" },
						{ type: "separator" },
						{ label: `退出 ${app.name}`, role: "quit" },
					],
				},
			]
			: []),
		{
			label: "文件",
			submenu: [
				{
					label: "保存到历史记录",
					click: (_i, w) => {
						//mainEdit(w, "save");
					},
					accelerator: "CmdOrCtrl+S",
				},
				{ type: "separator" },
				...(isMac
					? []
					: [
						{
							label: "设置",
							click: () => {
								//createSettingWindow();
							},
							accelerator: "CmdOrCtrl+,",
						},
						{ type: "separator" },
					]),
				{
					label: "其他编辑器打开",
					click: (_i, w) => {
						//mainEdit(w, "edit_on_other");
					},
				},
				{
					label: "打开方式...",
					click: (_i, w) => {
						//mainEdit(w, "choose_editer");
					},
				},
				{ type: "separator" },
				{
					id: "close",
					label: "关闭",
					role: "close",
					accelerator: "CmdOrCtrl+W",
				},
			],
		},
		{
			label: "编辑",
			submenu: [
				{
					label: "撤销",
					click: (_i, w) => {
						//mainEdit(w, "undo");
						//if (w instanceof BrowserWindow) w.webContents.undo();
					},
					accelerator: "CmdOrCtrl+Z",
				},
				{
					label: "重做",
					click: (_i, w) => {
						//mainEdit(w, "redo");
						//if (w instanceof BrowserWindow) w.webContents.redo();
					},
					accelerator: isMac ? "Cmd+Shift+Z" : "Ctrl+Y",
				},
				{ type: "separator" },
				{
					label: "剪切",
					click: (_i, w) => {
						//mainEdit(w, "cut");
						if (w instanceof BrowserWindow) w.webContents.cut();
					},
					accelerator: "CmdOrCtrl+X",
				},
				{
					label: "复制",
					click: (_i, w) => {
						mainEdit(w, "copy");
						if (w instanceof BrowserWindow) w.webContents.copy();
					},
					accelerator: "CmdOrCtrl+C",
				},
				{
					label: "粘贴",
					click: (_i, w) => {
						mainEdit(w, "paste");
						if (w instanceof BrowserWindow) w.webContents.paste();
					},
					accelerator: "CmdOrCtrl+V",
				},
				{
					label: "删除",
					click: (_i, w) => {
						mainEdit(w, "delete");
						if (w instanceof BrowserWindow) w.webContents.delete();
					},
				},
				{
					label: "全选",
					click: (_i, w) => {
						mainEdit(w, "select_all");
						if (w instanceof BrowserWindow)
							w.webContents.selectAll();
					},
					accelerator: "CmdOrCtrl+A",
				},
				{ type: "separator" },
				{
					label: "查找",
					click: (_i, w) => {
						mainEdit(w, "show_find");
					},
					accelerator: "CmdOrCtrl+F",
				},
				{
					label: "替换",
					click: (_i, w) => {
						mainEdit(w, "show_find");
					},
					accelerator: "CmdOrCtrl+F",
				},
				{ type: "separator" },
				{
					label: "自动换行",
					click: (_i, w) => {
						mainEdit(w, "wrap");
					},
				},
				{
					label: "拼写检查",
					click: (_i, w) => {
						mainEdit(w, "spellcheck");
					},
				},
				{ type: "separator" },
				...(isMac
					? [
						{
							label: "朗读",
							submenu: [
								{
									label: "开始朗读",
									role: "startSpeaking",
								},
								{
									label: "停止朗读",
									role: "stopSpeaking",
								},
							],
						},
					]
					: []),
			],
		},
		{
			label: "浏览器",
			submenu: [
				{
					label: "后退",
					click: (_i, w) => {
						viewEvents(w, "back");
					},
					accelerator: isMac ? "Command+[" : "Alt+Left",
				},
				{
					label: "前进",
					click: (_i, w) => {
						viewEvents(w, "forward");
					},
					accelerator: isMac ? "Command+]" : "Alt+Right",
				},
				{
					label: "刷新",
					click: (_i, w) => {
						viewEvents(w, "reload");
					},
					accelerator: "F5",
				},
				{
					label: "停止加载",
					click: (_i, w) => {
						viewEvents(w, "stop");
					},
					accelerator: "Esc",
				},
				{
					label: "浏览器打开",
					click: (_i, w) => {
						viewEvents(w, "browser");
					},
				},
				{
					label: "保存到历史记录",
					click: (_i, w) => {
						viewEvents(w, "add_history");
					},
					accelerator: "CmdOrCtrl+D",
				},
				{
					label: "开发者工具",
					click: (_i, w) => {
						viewEvents(w, "dev");
					},
				},
			],
		},
		{
			label: "视图",
			submenu: [
				{ label: "重新加载", role: "reload" },
				{ label: "强制重载", role: "forceReload" },
				{ label: "开发者工具", role: "toggleDevTools" },
				{ type: "separator" },
				{
					label: "历史记录",
					click: (_i, w) => {
						mainEdit(w, "show_history");
					},
					accelerator: "CmdOrCtrl+H",
				},
				{
					id: "show_photo",
					label: "图片区",
					click: (_i, w) => {
						mainEdit(w, "show_photo");
					},
					accelerator: "CmdOrCtrl+P",
				},
				{ type: "separator" },
				{ label: "实际大小", role: "resetZoom", accelerator: "" },
				{ label: "放大", role: "zoomIn" },
				{ label: "缩小", role: "zoomOut" },
				{ type: "separator" },
				{ label: "全屏", role: "togglefullscreen" },
			],
		},
		{
			label: "窗口",
			submenu: [
				{ label: "最小化", role: "minimize" },
				{ label: "关闭", role: "close" },
				...(isMac
					? [
						{ type: "separator" },
						{ label: "置于最前面", role: "front" },
						{ type: "separator" },
						{ label: "窗口", role: "window" },
					]
					: []),
			],
		},
		{
			label: "帮助",
			role: "help",
			submenu: [
				{
					label: "教程帮助",
					click: () => {
						//createHelpWindow();
					},
				},
				{ type: "separator" },
				{
					label: "关于",
					click: () => {
						//createSettingWindow(true);
					},
				},
			],
		},
	]

	const menu = Menu.buildFromTemplate(menuTemplate);
	Menu.setApplicationMenu(menu);
}

const viewEvents = (w, arg) => {
	if (w instanceof BrowserWindow) {
		w.webContents.send("view_events", arg);
	}
}

module.exports = {
	setMenu
}