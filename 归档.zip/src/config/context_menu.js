const {app,BrowserWindow,Tray,Menu} = require("electron");

const createContextMenu = (store,dev) => {
	let contextMenu = Menu.buildFromTemplate([
		{
			label: `自动识别`,
			click: () => {
				//autoOpen();
			},
		},
		{
			label: "截屏搜索",
			click: () => {
				setTimeout(() => {
					//showPhoto();
				}, 30);
			},
		},
		{
			label: "选中搜索",
			click: () => {
				//openSelection();
			},
		},
		{
			label: "剪贴板搜索",
			click: () => {
				//openClipBoard();
			},
		},
		{
			type: "separator",
		},
		{
			label: "文字识别（OCR）",
			click: () => {
				//sendCaptureEvent(undefined, "ocr");
			},
		},
		{
			label: "以图搜图",
			click: () => {
				//sendCaptureEvent(undefined, "search");
			},
		},
		{
			type: "separator",
		},
		{
			label: "浏览器打开",
			type: "checkbox",
			checked: store.get("浏览器中打开"),
			click: (i) => {
				store.set("浏览器中打开", i.checked);
			},
		},
		{
			type: "separator",
		},
		{
			label: "从剪贴板贴图",
			click: () => {
				//dingFromClipBoard();
			},
		},
		{
			type: "separator",
		},
		{
			label: "主页面模式",
			type: "submenu",
			submenu: [
				{
					label: "自动",
					type: "radio",
					checked: store.get("主页面.模式") === "auto",
					click: () => store.set("主页面.模式", "auto"),
				},
				{
					label: "搜索",
					type: "radio",
					checked: store.get("主页面.模式") === "search",
					click: () => store.set("主页面.模式", "search"),
				},
				{
					label: "翻译",
					type: "radio",
					checked: store.get("主页面.模式") === "translate",
					click: () => store.set("主页面.模式", "translate"),
				},
			],
		},
		{
			label: "复用主页面",
			toolTip: "可加快OCR加载",
			type: "checkbox",
			checked: store.get("主页面.复用"),
			click: (i) => store.set("主页面.复用", i.checked),
		},
		{ type: "separator" },
		{
			label: "主页面",
			click: () => {
				//createMainWindow({ type: "text", content: "" });
			},
		},
		{
			label: "设置",
			click: () => {
				//createSettingWindow();
			},
		},
		{
			label: "教程帮助",
			click: () => {
				//createHelpWindow();
			},
		},
		{
			type: "separator",
		},
		...(dev
			? [
				{
					label: "退出开发者模式",
					click: () => {
						store.set("dev", false);
						app.relaunch();
						app.exit(0);
					},
				},
			]
			: []),
		{
			label: "检查更新",
			click: async () => {
				//checkUpdate(true);
			},
		},
		{
			label: "反馈",
			click: (_i, win) => {
				shell.openExternal(
					feedbackUrl({
						title: `[${win?.getTitle()?.replace("eSearch - ", "") ?? "……界面"}] 存在……问题`,
					}),
				);
			},
		},
		{
			label: "反馈",
			click: () => {
				app.relaunch();
				app.exit(0);
			},
		},
		{
			label: "反馈",
			click: () => {
				app.quit();
			},
		},
	]);
	
	return contextMenu;
}



module.exports = {
	createContextMenu
}