import gc
import math
import os
import re
import sys
import time
import cv2

from numpy import array, zeros, uint8, float32,array
from PyQt5.QtCore import QPoint, QRectF, QMimeData
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl
from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtGui import QPixmap, QPainter, QPen, QIcon, QFont, QImage, QColor
from PyQt5.QtWidgets import QSlider, QColorDialog
from PyQt5.QtGui import QCursor, QBrush, QScreen,QWindow
from pynput.mouse import Controller

from pp.Public import TipsShower,PLATFORM_SYS,CONFIG_DICT,Commen_Thread
from pp.Widgets import FramelessEnterSendQTextEdit,Freezer
from pp.Func import cut_polypng,image_fill,cut_mutipic,get_line_interpolation,search_in_which_screen

from pp.PaintLayer import PaintLayer
from pp.MaskLayer import MaskLayer
from pp.AutotextEdit import AutotextEdit
from pp.CanMoveGroupbox import CanMoveGroupbox
from pp.HoverButton import HoverButton
from pp.HoverGroupbox import HoverGroupbox
from pp.ColorButton import ColorButton

class Slabel(QLabel):  # 区域截图功能
    showm_signal                 = pyqtSignal(str)
    recorder_recordchange_signal = pyqtSignal()
    close_signal                 = pyqtSignal()
    ocr_image_signal             = pyqtSignal(str)
    screen_shot_result_signal    = pyqtSignal(str)
    screen_shot_end_show_sinal   = pyqtSignal(QPixmap)
    set_area_result_signal       = pyqtSignal(list)
    getpix_result_signal         = pyqtSignal(tuple,QPixmap)

    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        if not os.path.exists("j_temp"):
            os.mkdir("j_temp")
    
    def screen_shot(self, pix=None,mode = "screenshot"):
        """mode: screenshot 、orc、set_area、getpix。screenshot普通截屏;非截屏模式:orc获取ocr源图片; set_area用于设置区域、getpix提取区域"""
        # 截屏函数,功能有二:当有传入pix时直接显示pix中的图片作为截屏背景,否则截取当前屏幕作为背景;前者用于重置所有修改
        # if PLATFORM_SYS=="darwin":
        self.sshoting = True
        t1 = time.process_time()
        pixRat = QWindow().devicePixelRatio()

        if type(pix) is QPixmap:
            get_pix = pix
            self.init_parameters()
        else:
            self.setup(mode)  # 初始化截屏
            sscreen = search_in_which_screen()
            
            # 截取屏幕    
            screenRet = sscreen.geometry().getRect()
            get_pix = sscreen.grabWindow(0,screenRet[0],screenRet[1],screenRet[2],screenRet[3])
            #get_pix = sscreen.grabWindow(0)
            get_pix.setDevicePixelRatio(pixRat)
        pixmap = QPixmap(get_pix.width(), get_pix.height())
        pixmap.setDevicePixelRatio(pixRat)
        pixmap.fill(Qt.transparent)  # 填充透明色,不然没有透明通道

        painter = QPainter(pixmap)
        painter.drawPixmap(0, 0, get_pix)
        painter.end()  # 一定要end

        self.originalPix = pixmap.copy()
        self.setPixmap(pixmap)
        self.mask.setGeometry(0, 0, get_pix.width(), get_pix.height())
        self.mask.show()

        self.paintlayer.setGeometry(0, 0, get_pix.width(), get_pix.height())
        self.paintlayer.setPixmap(QPixmap(get_pix.width(), get_pix.height()))
        self.paintlayer.pixmap().fill(Qt.transparent)  # 重点,不然不透明
        self.paintlayer.show()
        self.text_box.hide()
        self.botton_box.hide()
        self.setWindowOpacity(1)
        self.showFullScreen()

        if type(pix) is not QPixmap:
            self.backup_ssid = 0
            self.backup_pic_list = [self.originalPix.copy()]

        self.init_ss_thread_fun(get_pix)
        self.paintlayer.pixpng = QPixmap(":/msk.jpg")
        self.text_box.setTextColor(self.pencolor)

        # 以下设置样式
        self.text_box.setStyleSheet("background-color: rgba(0, 0, 0, 10);")
        self.setStyleSheet("QPushButton{color:black;background-color:rgb(239,239,239);padding:1px 4px;}""QPushButton:hover{color:green;background-color:rgb(200,200,100);}""QGroupBox{border:none;}")
        #print('sstime==========:', time.process_time() - t1)
        self.setFocus()
        self.setMouseTracking(True)
        self.activateWindow()
        self.raise_()
        self.update()
        QApplication.processEvents()

    def setup(self,mode = "screenshot"):  # 初始化界面
        self.on_init     = True
        self.mode        = mode
        self.paintlayer  = PaintLayer(self)  # 绘图层
        self.mask        = MaskLayer(self)  # 遮罩层
        self.text_box    = AutotextEdit(self)  # 文字工具类
        self.ocr_freezer = None
        self.shower     = FramelessEnterSendQTextEdit(self, enter_tra=True)  # 截屏时文字识别的小窗口
        self.settings    = QSettings('Fandes', 'jamtools')

        self.setMouseTracking(True)
        if PLATFORM_SYS == "darwin":
            self.setWindowFlags(Qt.FramelessWindowHint)
        else:
            self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint)  # Sheet

        self.botton_box  = QGroupBox(self)  # botton_box是截屏选框旁边那个按钮堆的box
        self.save_botton = QPushButton(QIcon(":/saveicon.png"), '', self.botton_box)
        self.save_botton.clicked.connect(lambda: self.cutpic(1))

        self.rect_btn          = QPushButton(self.botton_box)
        self.sure_btn          = QPushButton("确定", self.botton_box)
        self.freeze_img_botton = QPushButton(self.botton_box)
        self.pencolor          = QColor(Qt.red)
        self.Tipsshower        = TipsShower("  ", targetarea=(100, 70, 0, 0), parent=self)  # 左上角的大字提示

        self.Tipsshower.hide()
        self.shower.showm_signal.connect(self.Tipsshower.setText)
        self.init_slabel_ui()     
        self.init_parameters()
        self.backup_ssid = 0  # 当前备份数组的id,用于确定回退了几步
        self.backup_pic_list = []  # 备份页面的数组,用于前进/后退
        self.on_init = False

    def init_parameters(self):  # 初始化参数
        self.NpainterNmoveFlag          = self.choicing         = self.move_rect        = self.move_y0 = self.move_x0 = self.move_x1 = self.change_alpha = self.move_y1    = False
        self.x0                         = self.y0               = self.rx0              = self.ry0     = self.x1      = self.y1      = self.mouse_posx   = self.mouse_posy = -50
        self.bx                         = self.by               = 0
        # 透明度值
        self.alpha                      = 255  
        #边框线宽
        self.tool_width                 = 1
        self.smartcursor_on             = self.settings.value("screenshot/smartcursor", True, type=bool)
        self.finding_rect               = True  # 正在自动寻找选取的控制变量, 就进入截屏之后会根据鼠标移动到的位置自动选取,
        self.roller_area                = (0, 0, 1, 1)
        self.backgrounderaser_pointlist = []  # 下面xxpointlist都是储存绘图数据的列表
        self.eraser_pointlist           = []
        self.pen_pointlist              = []
        self.drawpix_pointlist          = []
        self.repairbackground_pointlist = []
        self.drawtext_pointlist         = []
        self.perspective_cut_pointlist  = []
        self.polygon_ss_pointlist       = []
        self.drawrect_pointlist         = [[-2, -2], [-2, -2], 0]
        self.drawarrow_pointlist        = [[-2, -2], [-2, -2], 0]
        self.drawcircle_pointlist       = [[-2, -2], [-2, -2], 0]
        self.painter_tools              = {
            'drawpix_bs_on'      : 0,
            'drawarrow_on'       : 0,
            'drawcircle_on'      : 0,
            'drawrect_bs_on'     : 0,
            'pen_on'             : 0,
            'eraser_on'          : 0,
            'drawtext_on'        : 0,
            'backgrounderaser_on': 0,
            'selectcolor_on'     : 0,
            "bucketpainter_on"   : 0,
            "repairbackground_on": 0,
            "perspective_cut_on" : 0,
            "polygon_ss_on"      : 0
        }
        self.old_pen = self.old_eraser = self.old_brush = self.old_backgrounderaser = [-2, -2]
        self.left_button_push = False

    def init_slabel_ui(self):  # 初始化界面的参数
        self.shower.hide()
        self.setToolTip("左键框选，右键返回")
                
        self.save_botton.setGeometry(0, 0, 40, 35)
        self.save_botton.setToolTip('另存为文件')

        self.freeze_img_botton.setGeometry(self.save_botton.x() + self.save_botton.width(), 0, 40, 35)
        self.freeze_img_botton.setIcon(QIcon(":/freeze.png"))
        self.freeze_img_botton.setToolTip('固定图片于屏幕上')
        self.freeze_img_botton.clicked.connect(self.freeze_img)

        self.rect_btn.setGeometry(self.freeze_img_botton.x() + self.freeze_img_botton.width(), 0, 40, 35)
        self.rect_btn.setIcon(QIcon(":/rect.png"))
        self.rect_btn.setToolTip('矩形工具')
        self.rect_btn.clicked.connect(self.change_bs_fun)

        self.sure_btn.setGeometry(self.rect_btn.x() + self.rect_btn.width(), 0, 60, 35)
        self.sure_btn.clicked.connect(self.cutpic)

        self.botton_box.resize(self.sure_btn.width() + self.rect_btn.width() + self.save_botton.width() + self.freeze_img_botton.width(), self.sure_btn.height())
        self.botton_box.hide()

        tipsfont = QFont("", 35)
        self.Tipsshower.setFont(tipsfont)
        
    def closenomalcolorboxsignalhandle(self, s):  # 关闭常见颜色浮窗的函数
        if s:
            try:
                self.closenomalcolorboxtimer.stop()
            except:
                print(sys.exc_info(), 1162)
        else:
            print("离开box信号", s)

            self.closenomalcolorboxtimer.start(1000)

    def change_tools_fun(self, r):  # 更改工具时统一调用的函数,用于重置所有样式
        self.text_box.clear()
        self.text_box.hide()
        for tool in self.painter_tools:
            if tool == r:
                self.painter_tools[tool] = 1
            else:
                self.painter_tools[tool] = 0
        self.update()

    def change_bs_fun(self):
        if self.painter_tools['drawrect_bs_on']:
            self.painter_tools['drawrect_bs_on'] = 0
        else:
            self.change_tools_fun('drawrect_bs_on')
            self.Tipsshower.setText("矩形框工具")
    
    def init_ss_thread_fun(self, get_pix):  # 后台初始化截屏线程,用于寻找所有智能选区
        self.x0 = self.y0 = 0
        self.x1 = QApplication.desktop().width()
        self.y1 = QApplication.desktop().height()
        self.mouse_posx = self.mouse_posy = -150
        self.qimg = get_pix.toImage()
        temp_shape = (self.qimg.height(), self.qimg.width(), 4)
        ptr = self.qimg.bits()
        ptr.setsize(self.qimg.byteCount())
        result = array(ptr, dtype=uint8).reshape(temp_shape)[..., :3]
        QApplication.processEvents()

    def backup_shortshot(self):
        if self.backup_ssid != len(self.backup_pic_list) - 1:
            self.backup_pic_list = self.backup_pic_list[:self.backup_ssid + 1]
        while len(self.backup_pic_list) >= 10:
            self.backup_pic_list.pop(0)
        allpix = self.cutpic(save_as=3)
        self.backup_pic_list.append(QPixmap(allpix))
        self.backup_ssid = len(self.backup_pic_list) - 1
        print("备份动作", self.backup_ssid, len(self.backup_pic_list))
        # self.update()

    def freeze_img(self):
        self.cutpic(save_as=2)
        self.parent.freeze_imgs.append(Freezer(None, self.final_get_img,min(self.x0, self.x1), min(self.y0, self.y1),len(self.parent.freeze_imgs)))
        if not QSettings('Fandes', 'jamtools').value("S_SIMPLE_MODE", False, bool):
            self.parent.show()
        self.clear_and_hide()

    def ocr_res_signalhandle(self, text):
        self.shower.setPlaceholderText("")
        self.shower.insertPlainText(text)

    def choice(self):  # 选区完毕后显示选择按钮的函数
        self.choicing = True

        botton_boxw = self.x1 + 5
        botton_boxh = self.y1 + 5
        dx = abs(self.x1 - self.x0)
        dy = abs(self.y1 - self.y0)
        x = QApplication.desktop().width()
        y = QApplication.desktop().height()
        if dx < self.botton_box.width() + 10:
            if max(self.x1, self.x0) + self.botton_box.width() > x:
                botton_boxw = min(self.x0, self.x1) - self.botton_box.width() - 5
            else:
                botton_boxw = max(self.x1, self.x0) + 5
        else:
            if self.x1 > self.x0:
                botton_boxw = self.x1 - self.botton_box.width() - 5
        if dy < self.botton_box.height() + 105:
            if max(self.y1, self.y0) + self.botton_box.height() + 20 > y:
                botton_boxh = min(self.y0, self.y1) - self.botton_box.height() - 5
            else:
                botton_boxh = max(self.y0, self.y1) + 5
        else:
            if self.y1 > self.y0:
                botton_boxh = self.y1 - self.botton_box.height() - 5
        self.botton_box.move(botton_boxw, botton_boxh)
        self.botton_box.show()

    def cutpic(self, save_as=0):  # 裁剪图片
        """裁剪图片,0:正常截图保存模式, 1:另存为模式, 2:内部调用保存图片, 3:内部调用,直接返回图片"""
        self.sshoting = False
        transparentpix = self.pixmap().copy()
        paintlayer = self.paintlayer.pixmap()
        painter = QPainter(transparentpix)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.drawPixmap(0, 0, paintlayer)
        painter.end()  # 一定要end

        if save_as == 3:  # 油漆桶工具
            return transparentpix

        pix = QPixmap(transparentpix.width(), transparentpix.height())
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        p.drawPixmap(0, 0, transparentpix)
        p.end()

        x0 = min(self.x0, self.x1)
        y0 = min(self.y0, self.y1)
        x1 = max(self.x0, self.x1)
        y1 = max(self.y0, self.y1)
        w = x1 - x0
        h = y1 - y0

        # print(x0, y0, x1, y1)
        if (x1 - x0) < 1 or (y1 - y0) < 1:
            self.Tipsshower.setText("范围过小<1")
            return
        self.final_get_img = pix.copy(x0, y0, w, h)

        if save_as:
            if save_as == 1:
                #默认保存到桌面
                path, l = QFileDialog.getSaveFileName(self, "保存为", QStandardPaths.writableLocation(QStandardPaths.DesktopLocation), "img Files (*.PNG *.jpg *.JPG *.JPEG *.BMP *.ICO)")
                if path:
                    print(path)
                    transparentpix.save(path)
                    self.clear_and_hide()
                else:
                    return
            elif save_as == 2:
                return
        if __name__ == '__main__':  # 当直接运行本文件时直接保存,测试用
            self.final_get_img.save('j_temp/{}.png'.format(CONFIG_DICT["last_pic_save_name"]))
            QApplication.clipboard().setPixmap(self.final_get_img)
            print("已复制到剪切板")
            self.clear_and_hide()
            return
        # 以下为作者软件的保存操作,懒得删了...
        if self.mode == "set_area":
            area = [x0,y0,(x1 - x0 + 1) // 2 * 2,(y1 - y0 + 1) // 2 * 2]
            if area[2] == 0 or area[3] == 0:
                self.showm_signal.emit('选择范围过小，请重新选择！')
            else:
                self.set_area_result_signal.emit(area)
            if not QSettings('Fandes', 'jamtools').value("S_SIMPLE_MODE", False, bool):
                self.parent.show()
        elif self.mode == "getpix":
            self.getpix_result_signal.emit((x0, y0, w, h),self.final_get_img)
            if not QSettings('Fandes', 'jamtools').value("S_SIMPLE_MODE", False, bool):
                self.parent.show()
        else:
            def save():
                CONFIG_DICT["last_pic_save_name"]="{}".format( str(time.strftime("%Y-%m-%d_%H.%M.%S", time.localtime())))
                filepath = 'j_temp/{}.png'.format(CONFIG_DICT["last_pic_save_name"])
                self.final_get_img.save(filepath)
                if self.mode == "screenshot":
                    self.screen_shot_result_signal.emit(filepath)
                print('saved')

            self.save_data_thread = Commen_Thread(save)
            self.save_data_thread.start()
            st = time.process_time()
            self.manage_data()
            print('managetime:', time.process_time() - st)
        self.clear_and_hide()

    def manage_data(self):
        """截屏完之后数据处理,不用可自己写"""
        if self.mode == "screenshot":
            if not QSettings('Fandes', 'jamtools').value("S_SIMPLE_MODE", False, bool):
                self.screen_shot_end_show_sinal.emit(self.final_get_img)

            clipboard = QApplication.clipboard()
            try:
                if self.parent.settings.value('screenshot/copy_type_ss', '图像数据', type=str) == '图像数据':
                    clipboard.setPixmap(self.final_get_img)
                    print('sava 图像数据')
                    self.showm_signal.emit('图像数据已复制到剪切板！')
                elif self.parent.settings.value('screenshot/copy_type_ss', '图像数据', type=str) == '图像文件':
                    self.save_data_thread.wait()
                    data = QMimeData()
                    url = QUrl.fromLocalFile(os.getcwd()+'/j_temp/{}.png'.format(CONFIG_DICT["last_pic_save_name"]))
                    data.setUrls([url])
                    clipboard.setMimeData(data)
                    print('save url {}'.format(url))
                    self.showm_signal.emit('图像文件已复制到剪切板！')
            except:
                clipboard.setPixmap(self.final_get_img)
                self.showm_signal.emit('图像数据已复制到剪切板！')
        elif self.mode == "ocr":
            try:
                self.save_data_thread.wait()
                self.ocr_image_signal.emit('j_temp/{}.png'.format(CONFIG_DICT["last_pic_save_name"]))
            except:
                print(sys.exc_info(), 1822)

    def cut_polygonpng(self):
        allpix = self.cutpic(save_as=3)
        self.qimg = allpix.toImage()
        temp_shape = (self.qimg.height(), self.qimg.width(), 4)
        ptr = self.qimg.bits()
        ptr.setsize(self.qimg.byteCount())
        cv2img = array(ptr, dtype=uint8).reshape(temp_shape)[..., :3]
        polygoncv2pic = cut_polypng(cv2img, self.polygon_ss_pointlist)
        cv2.imwrite('j_temp/{}.png'.format(CONFIG_DICT["last_pic_save_name"]), polygoncv2pic)
        self.polygon_ss_pointlist = []
        QApplication.clipboard().setImage(QImage('j_temp/{}.png'.format(CONFIG_DICT["last_pic_save_name"])))
        self.showm_signal.emit("已复制到剪切板")
        self.clear_and_hide()

    def mouseDoubleClickEvent(self, e):  # 双击
        if e.button() == Qt.LeftButton:
            if self.painter_tools["polygon_ss_on"]:
                self.change_tools_fun("")
                print("裁剪点", self.polygon_ss_pointlist)
                self.cut_polygonpng()
            print("左键双击")

    # 鼠标点击事件
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:  # 按下了左键
            self.left_button_push = True
            if 1 in self.painter_tools.values():  # 如果有绘图工具打开了,说明正在绘图
                if self.painter_tools['drawrect_bs_on']:
                    # print("ch",self.drawrect_pointlist)
                    self.drawrect_pointlist = [[event.x(), event.y()], [-2, -2], 0]
                elif self.painter_tools['drawarrow_on']:
                    self.drawarrow_pointlist = [[event.x(), event.y()], [-2, -2], 0]
                    # self.drawarrow_pointlist[0] = [event.x(), event.y()]
                elif self.painter_tools['drawcircle_on']:
                    self.drawcircle_pointlist = [[event.x(), event.y()], [-2, -2], 0]
                    # self.drawcircle_pointlist[0] = [event.x(), event.y()]
                elif self.painter_tools['drawtext_on']:
                    self.text_box.move(event.x(), event.y())
                    self.drawtext_pointlist.append([event.x(), event.y()])
                    self.text_box.setFont(QFont('', self.tool_width))
                    self.text_box.setTextColor(self.pencolor)
                    self.text_box.textAreaChanged()
                    self.text_box.show()
                    self.text_box.setFocus()
                elif self.painter_tools['selectcolor_on']:
                    allpix = self.cutpic(save_as=3)
                    self.qimg = allpix.toImage()
                    color = self.qimg.pixelColor(event.x(), event.y())
                    self.pencolor = color
                    self.change_tools_fun("")
                elif self.painter_tools['bucketpainter_on']:  # 油漆桶工具
                    allpix = self.cutpic(save_as=3)
                    self.qimg = allpix.toImage()
                    temp_shape = (self.qimg.height(), self.qimg.width(), 4)
                    ptr = self.qimg.bits()
                    ptr.setsize(self.qimg.byteCount())
                    ci = array(ptr, dtype=uint8).reshape(temp_shape)[..., :3]

                    cv2img = image_fill(cv2.cvtColor(ci, cv2.COLOR_RGB2BGR), event.x(), event.y(),(self.pencolor.red(), self.pencolor.green(), self.pencolor.blue()))
                    height, width, depth = cv2img.shape
                    pix = QPixmap.fromImage(QImage(cv2img.data, width, height, width * depth, QImage.Format_RGB888))
                    tpix = QPixmap(pix.width(), pix.height())
                    tpix.fill(Qt.transparent)
                    p = QPainter(tpix)
                    p.drawPixmap(0, 0, pix)
                    p.end()
                    self.setPixmap(tpix)
                    self.paintlayer.pixmap().fill(Qt.transparent)
                    self.Tipsshower.setText("已填充并合并图层!", color=QColor(Qt.green))
                    allpix = self.cutpic(save_as=3)
                    self.qimg = allpix.toImage()
                elif self.painter_tools["polygon_ss_on"]:

                    if len(self.polygon_ss_pointlist) and self.polygon_ss_pointlist[0][0] - 10 < event.x() < \
                            self.polygon_ss_pointlist[0][0] + 10 and self.polygon_ss_pointlist[0][
                        1] - 10 < event.y() < self.polygon_ss_pointlist[0][1] + 10:
                        print("相同点结束")
                        self.setCursor(QCursor(QPixmap(":/smartcursor.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                        self.cut_polygonpng()
                    else:
                        self.setCursor(QCursor(QPixmap(":/polygon_ss.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                        self.polygon_ss_pointlist.append([event.x(), event.y()])

                elif self.painter_tools["perspective_cut_on"]:
                    self.setCursor(QCursor(QPixmap(":/perspective.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                    self.perspective_cut_pointlist.append([event.x(), event.y()])
                    if len(self.perspective_cut_pointlist) >= 4:
                        allpix = self.cutpic(save_as=3)
                        self.qimg = allpix.toImage()
                        temp_shape = (self.qimg.height(), self.qimg.width(), 4)
                        ptr = self.qimg.bits()
                        ptr.setsize(self.qimg.byteCount())
                        cv2img = array(ptr, dtype=uint8).reshape(temp_shape)[..., :3]
                        res = cut_mutipic(cv2img, self.perspective_cut_pointlist)
                        cv2.imwrite("perspective_cut.jpg", res)
                        QApplication.clipboard().setImage(QImage("perspective_cut.jpg"))
                        # cv2.imwrite("respng.png",res)
                        self.Tipsshower.setText("已复制到剪切板!")
                        print("四个点", self.perspective_cut_pointlist)
                        self.setCursor(Qt.ArrowCursor)
                        self.perspective_cut_pointlist = []
                        self.change_tools_fun("")
                        self.choicing = False
                        self.finding_rect = True
            else:  # 否则说明正在选区或移动选区
                r = 0
                x0 = min(self.x0, self.x1)
                x1 = max(self.x0, self.x1)
                y0 = min(self.y0, self.y1)
                y1 = max(self.y0, self.y1)
                my = (y1 + y0) // 2
                mx = (x1 + x0) // 2
                # print(x0, x1, y0, y1, mx, my, event.x(), event.y())
                # 以下为判断点击在哪里
                if not self.finding_rect and (self.x0 - 8 < event.x() < self.x0 + 8) and (
                        my - 8 < event.y() < my + 8 or y0 - 8 < event.y() < y0 + 8 or y1 - 8 < event.y() < y1 + 8):
                    self.move_x0 = True
                    r = 1

                elif not self.finding_rect and (self.x1 - 8 < event.x() < self.x1 + 8) and (
                        my - 8 < event.y() < my + 8 or y0 - 8 < event.y() < y0 + 8 or y1 - 8 < event.y() < y1 + 8):
                    self.move_x1 = True
                    r = 1
                    # print('x1')

                elif not self.finding_rect and (self.y0 - 8 < event.y() < self.y0 + 8) and (
                        mx - 8 < event.x() < mx + 8 or x0 - 8 < event.x() < x0 + 8 or x1 - 8 < event.x() < x1 + 8):
                    self.move_y0 = True
                    print('y0')
                elif not self.finding_rect and self.y1 - 8 < event.y() < self.y1 + 8 and (
                        mx - 8 < event.x() < mx + 8 or x0 - 8 < event.x() < x0 + 8 or x1 - 8 < event.x() < x1 + 8):
                    self.move_y1 = True

                elif (x0 + 8 < event.x() < x1 - 8) and (
                        y0 + 8 < event.y() < y1 - 8) and not self.finding_rect:
                    # if not self.finding_rect:
                    self.move_rect = True
                    self.setCursor(Qt.SizeAllCursor)
                    self.bx = abs(max(self.x1, self.x0) - event.x())
                    self.by = abs(max(self.y1, self.y0) - event.y())
                else:
                    self.NpainterNmoveFlag = True  # 没有绘图没有移动还按下了左键,说明正在选区,标志变量
                    # if self.finding_rect:
                    #     self.rx0 = event.x()
                    #     self.ry0 = event.y()
                    # else:
                    self.rx0 = event.x()  # 记录下点击位置
                    self.ry0 = event.y()
                    if self.x1 == -50:
                        self.x1 = event.x()
                        self.y1 = event.y()

                    # print('re')
                if r:  # 判断是否点击在了对角线上
                    if (self.y0 - 8 < event.y() < self.y0 + 8) and (
                            x0 - 8 < event.x() < x1 + 8):
                        self.move_y0 = True
                        # print('y0')
                    elif self.y1 - 8 < event.y() < self.y1 + 8 and (
                            x0 - 8 < event.x() < x1 + 8):
                        self.move_y1 = True
                        # print('y1')
            if self.finding_rect:
                self.finding_rect = False
                # self.finding_rectde = True
            self.botton_box.hide()
            self.update()

    # 鼠标释放事件
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.left_button_push = False
            if 1 in self.painter_tools.values():  # 绘图工具松开
                if self.painter_tools['pen_on']:
                    self.pen_pointlist.append([-2, -2])
                elif self.painter_tools['drawpix_bs_on']:
                    self.drawpix_pointlist.append([-2, -2])
                elif self.painter_tools['repairbackground_on']:
                    self.repairbackground_pointlist.append([-2, -2])
                elif self.painter_tools['drawrect_bs_on']:
                    self.drawrect_pointlist[1] = [event.x(), event.y()]
                    self.drawrect_pointlist[2] = 1
                elif self.painter_tools['drawarrow_on']:
                    self.drawarrow_pointlist[1] = [event.x(), event.y()]
                    self.drawarrow_pointlist[2] = 1
                elif self.painter_tools['drawcircle_on']:
                    self.drawcircle_pointlist[1] = [event.x(), event.y()]
                    self.drawcircle_pointlist[2] = 1
                elif self.painter_tools['eraser_on']:
                    self.eraser_pointlist.append([-2, -2])
                elif self.painter_tools['backgrounderaser_on']:
                    self.backgrounderaser_pointlist.append([-2, -2])
                if not self.painter_tools["perspective_cut_on"] and not self.painter_tools["polygon_ss_on"]:
                    self.backup_shortshot()
            else:  # 调整选区松开
                self.setCursor(Qt.ArrowCursor)
            self.NpainterNmoveFlag = False  # 选区结束标志置零
            self.move_rect = self.move_y0 = self.move_x0 = self.move_x1 = self.move_y1 = False
            if not self.painter_tools["perspective_cut_on"] and not self.painter_tools["polygon_ss_on"]:
                self.choice()
            # self.sure_btn.show()
            
        elif event.button() == Qt.RightButton:  # 右键
            self.setCursor(Qt.ArrowCursor)
            if 1 in self.painter_tools.values():  # 退出绘图工具
                if self.painter_tools["selectcolor_on"]:
                    self.Tipsshower.setText("取消取色器")
                    
                if self.painter_tools["perspective_cut_on"] and len(self.perspective_cut_pointlist) > 0:
                    self.setCursor(QCursor(QPixmap(":/perspective.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                    self.perspective_cut_pointlist.pop()
                    # if not len(self.perspective_cut_pointlist):
                    #     self.choicing = False
                    #     self.finding_rect = True
                elif self.painter_tools["polygon_ss_on"] and len(self.polygon_ss_pointlist) > 0:
                    self.setCursor(QCursor(QPixmap(":/polygon_ss.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                    self.polygon_ss_pointlist.pop()
                    # if not len(self.polygon_ss_pointlist):
                    #     self.choicing = False
                    #     self.finding_rect = True
                else:
                    self.choicing = False
                    self.finding_rect = True
                    self.shower.hide()
                    self.change_tools_fun("")

            elif self.choicing:  # 退出选定的选区
                self.botton_box.hide()
                self.choicing = False
                self.finding_rect = True
                self.shower.hide()
                self.x0 = self.y0 = self.x1 = self.y1 = -50
            else:  # 退出截屏
                try:
                    if not QSettings('Fandes', 'jamtools').value("S_SIMPLE_MODE", False, bool):
                        self.parent.show()

                    self.parent.bdocr = False
                except:
                    print(sys.exc_info(), 2051)
                self.clear_and_hide()
            self.update()
    
    # 鼠标滑轮事件
    def wheelEvent(self, event):
        if self.isVisible():
            angleDelta = event.angleDelta() / 8
            dy = angleDelta.y()
            # print(dy)
            if self.change_alpha:  # 正在调整透明度
                self.Tipsshower.setText("透明度值{}".format(self.alpha))
            else:  # 否则是调节画笔大小
                # angleDelta = event.angleDelta() / 8
                # dy = angleDelta.y()
                # print(dy)
                if dy > 0:
                    self.tool_width += 1
                elif self.tool_width > 1:
                    self.tool_width -= 1
                self.Tipsshower.setText("大小{}px".format(self.tool_width))

                # if 1 in self.painter_tools.values():

                if self.painter_tools['drawtext_on']:
                    # self.text_box.move(event.x(), event.y())
                    # self.drawtext_pointlist.append([event.x(), event.y()])
                    self.text_box.setFont(QFont('', self.tool_width))
                    # self.text_box.setTextColor(self.pencolor)
                    self.text_box.textAreaChanged()
            self.update()

    # 鼠标移动事件
    def mouseMoveEvent(self, event):
        if self.isVisible():
            self.mouse_posx = event.x()  # 先储存起鼠标位置,用于画笔等的绘图计算
            self.mouse_posy = event.y()
            if 1 in self.painter_tools.values():  # 如果有绘图工具已经被选择,说明正在绘图
                self.paintlayer.px = event.x()
                self.paintlayer.py = event.y()
                if self.left_button_push:
                    if self.painter_tools['pen_on']:
                        self.pen_pointlist.append([event.x(), event.y()])
                    elif self.painter_tools['drawpix_bs_on']:
                        self.drawpix_pointlist.append([event.x(), event.y()])
                    elif self.painter_tools['repairbackground_on']:
                        self.repairbackground_pointlist.append([event.x(), event.y()])
                    elif self.painter_tools['drawrect_bs_on']:
                        self.drawrect_pointlist[1] = [event.x(), event.y()]
                    elif self.painter_tools['drawarrow_on']:
                        self.drawarrow_pointlist[1] = [event.x(), event.y()]
                    elif self.painter_tools['drawcircle_on']:
                        self.drawcircle_pointlist[1] = [event.x(), event.y()]
                    elif self.painter_tools['eraser_on']:
                        self.eraser_pointlist.append([event.x(), event.y()])
                    elif self.painter_tools['backgrounderaser_on']:
                        # print('bakpoint')
                        self.backgrounderaser_pointlist.append([event.x(), event.y()])
                    elif self.painter_tools["polygon_ss_on"]:
                        self.polygon_ss_pointlist.append([event.x(), event.y()])
                if self.painter_tools['pen_on']:
                    self.setCursor(QCursor(QPixmap(":/pen.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['drawpix_bs_on']:
                    self.setCursor(QCursor(self.paintlayer.pixpng.scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['repairbackground_on']:
                    self.setCursor(QCursor(QPixmap(":/backgroundrepair.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 26))
                elif self.painter_tools['drawrect_bs_on']:
                    self.setCursor(QCursor(QPixmap(":/mouse.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 30))
                elif self.painter_tools['drawarrow_on']:
                    self.setCursor(QCursor(QPixmap(":/arrowicon.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['drawcircle_on']:
                    self.setCursor(QCursor(QPixmap(":/circle.png").scaled(32, 32, Qt.KeepAspectRatio), 16, 16))
                elif self.painter_tools['drawtext_on']:
                    self.setCursor(QCursor(QPixmap(":/texticon.png").scaled(16, 16, Qt.KeepAspectRatio), 0, 0))
                elif self.painter_tools['eraser_on']:
                    self.setCursor(QCursor(QPixmap(":/eraser.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['backgrounderaser_on']:
                    self.setCursor(QCursor(QPixmap(":/backgrounderaser.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['selectcolor_on']:
                    color = self.qimg.pixelColor(event.x(), event.y())
                    self.setCursor(QCursor(QPixmap(":/colorsampler.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 31))
                elif self.painter_tools['bucketpainter_on']:
                    self.setCursor(QCursor(QPixmap(":/yqt.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['perspective_cut_on']:
                    self.setCursor(QCursor(QPixmap(":/perspective.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                elif self.painter_tools['polygon_ss_on']:
                    if len(self.polygon_ss_pointlist) and self.polygon_ss_pointlist[0][0] - 10 < event.x() < \
                            self.polygon_ss_pointlist[0][0] + 10 and self.polygon_ss_pointlist[0][
                        1] - 10 < event.y() < self.polygon_ss_pointlist[0][1] + 10:
                        self.setCursor(QCursor(QPixmap(":/smartcursor.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
                    else:
                        self.setCursor(QCursor(QPixmap(":/polygon_ss.png").scaled(32, 32, Qt.KeepAspectRatio), 0, 32))
            else:  # 不在绘画
                minx = min(self.x0, self.x1)
                maxx = max(self.x0, self.x1)
                miny = min(self.y0, self.y1)
                maxy = max(self.y0, self.y1)  # 以上取选区的最小值和最大值
                my = (maxy + miny) // 2
                mx = (maxx + minx) // 2  # 取中间值
                if ((minx - 8 < event.x() < minx + 8) and (miny - 8 < event.y() < miny + 8)) or \
                        ((maxx - 8 < event.x() < maxx + 8) and (maxy - 8 < event.y() < maxy + 8)):
                    self.setCursor(Qt.SizeFDiagCursor)
                elif ((minx - 8 < event.x() < minx + 8) and (maxy - 8 < event.y() < maxy + 8)) or \
                        ((maxx - 8 < event.x() < maxx + 8) and (miny - 8 < event.y() < miny + 8)):
                    self.setCursor(Qt.SizeBDiagCursor)
                elif (self.x0 - 8 < event.x() < self.x0 + 8) and (
                        my - 8 < event.y() < my + 8 or miny - 8 < event.y() < miny + 8 or maxy - 8 < event.y() < maxy + 8):
                    self.setCursor(Qt.SizeHorCursor)
                elif (self.x1 - 8 < event.x() < self.x1 + 8) and (
                        my - 8 < event.y() < my + 8 or miny - 8 < event.y() < miny + 8 or maxy - 8 < event.y() < maxy + 8):
                    self.setCursor(Qt.SizeHorCursor)
                elif (self.y0 - 8 < event.y() < self.y0 + 8) and (
                        mx - 8 < event.x() < mx + 8 or minx - 8 < event.x() < minx + 8 or maxx - 8 < event.x() < maxx + 8):
                    self.setCursor(Qt.SizeVerCursor)
                elif (self.y1 - 8 < event.y() < self.y1 + 8) and (
                        mx - 8 < event.x() < mx + 8 or minx - 8 < event.x() < minx + 8 or maxx - 8 < event.x() < maxx + 8):
                    self.setCursor(Qt.SizeVerCursor)
                elif (minx + 8 < event.x() < maxx - 8) and (
                        miny + 8 < event.y() < maxy - 8):
                    if self.move_rect:
                        self.setCursor(Qt.SizeAllCursor)
                    # self.setCursor(Qt.SizeAllCursor)
                elif self.move_x1 or self.move_x0 or self.move_y1 or self.move_y0:  # 再次判断防止光标抖动
                    b = (self.x1 - self.x0) * (self.y1 - self.y0) > 0
                    if (self.move_x0 and self.move_y0) or (self.move_x1 and self.move_y1):
                        if b:
                            self.setCursor(Qt.SizeFDiagCursor)
                        else:
                            self.setCursor(Qt.SizeBDiagCursor)
                    elif (self.move_x1 and self.move_y0) or (self.move_x0 and self.move_y1):
                        if b:
                            self.setCursor(Qt.SizeBDiagCursor)
                        else:
                            self.setCursor(Qt.SizeFDiagCursor)
                    elif (self.move_x0 or self.move_x1) and not (self.move_y0 or self.move_y1):
                        self.setCursor(Qt.SizeHorCursor)
                    elif not (self.move_x0 or self.move_x1) and (self.move_y0 or self.move_y1):
                        self.setCursor(Qt.SizeVerCursor)
                    # elif self.move_rect:
                    #     self.setCursor(Qt.SizeAllCursor)
                else:
                    self.setCursor(Qt.ArrowCursor)
                # 以上几个ifelse都是判断鼠标移动的位置和选框的关系然后设定光标形状
                # print(11)
                if self.NpainterNmoveFlag:  # 如果没有在绘图也没在移动(调整)选区,在选区,则不断更新选区的数值
                    # self.sure_btn.hide()
                    # self.roll_ss_btn.hide()
                    self.x1 = event.x()  # 储存当前位置到self.x1下同
                    self.y1 = event.y()
                    self.x0 = self.rx0  # 鼠标按下时记录的坐标,下同
                    self.y0 = self.ry0
                    if self.y1 > self.y0:  # 下面是边界修正,由于选框占用了一个像素,否则有误差
                        self.y1 += 1
                    else:
                        self.y0 += 1
                    if self.x1 > self.x0:
                        self.x1 += 1
                    else:
                        self.x0 += 1
                else:  # 说明在移动或者绘图,不过绘图没有什么处理的,下面是处理移动/拖动选区
                    if self.move_x0:  # 判断拖动标志位,下同
                        self.x0 = event.x()
                    elif self.move_x1:
                        self.x1 = event.x()
                    if self.move_y0:
                        self.y0 = event.y()
                    elif self.move_y1:
                        self.y1 = event.y()
                    elif self.move_rect:  # 拖动选框
                        dx = abs(self.x1 - self.x0)
                        dy = abs(self.y1 - self.y0)
                        if self.x1 > self.x0:
                            self.x1 = event.x() + self.bx
                            self.x0 = self.x1 - dx
                        else:
                            self.x0 = event.x() + self.bx
                            self.x1 = self.x0 - dx

                        if self.y1 > self.y0:
                            self.y1 = event.y() + self.by
                            self.y0 = self.y1 - dy
                        else:
                            self.y0 = event.y() + self.by
                            self.y1 = self.y0 - dy
            self.update()  # 更新界面

    def keyPressEvent(self, e):  # 按键按下,没按一个键触发一次
        super(Slabel, self).keyPressEvent(e)
        # self.pixmap().save(temp_path + '/aslfdhds.png')
        if e.key() == Qt.Key_Escape:  # 退出
            self.clear_and_hide()
        elif e.key() == Qt.Key_Control:  # 按住ctrl,更改透明度标志位置一
            print("cahnge")
            self.change_alpha = True

        elif self.change_alpha:  # 如果已经按下了ctrl
            if e.key() == Qt.Key_S:  # 还按下了s,说明是保存,ctrl+s
                self.cutpic(1)
            elif not self.painter_tools["polygon_ss_on"] and not self.painter_tools["perspective_cut_on"]:
                pass

    def keyReleaseEvent(self, e) -> None:  # 按键松开
        super(Slabel, self).keyReleaseEvent(e)
        if e.key() == Qt.Key_Control:
            self.change_alpha = False

    def clear_and_hide(self):  # 清理退出
        print("clear and hide")
        if self.ocr_freezer is not None:
            self.ocr_freezer.clear()
        if PLATFORM_SYS == "darwin":  # 如果系统为macos
            print("drawin hide")
            self.setWindowOpacity(0)
            self.showNormal()
        self.hide()
        self.clearotherthread = Commen_Thread(self.clear_and_hide_thread)
        self.clearotherthread.start()

    def clear_and_hide_thread(self):  # 后台等待线程
        self.close_signal.emit()
        try:
            self.save_data_thread.wait()
        except:
            print(sys.exc_info(), 2300)

    # 绘制事件
    def paintEvent(self, event):  # 绘图函数,每次调用self.update时触发
        super().paintEvent(event)
        if self.on_init:
            print('oninit return')
            return
        pixPainter = QPainter(self.pixmap())  # 画笔
        while len(self.backgrounderaser_pointlist):  # 背景橡皮擦工具有值,则说明正在使用背景橡皮擦
            # print(self.backgrounderaser_pointlist)
            pixPainter.setRenderHint(QPainter.Antialiasing)
            pixPainter.setBrush(QColor(0, 0, 0, 0))
            pixPainter.setPen(Qt.NoPen)
            # pixPainter.setPen(Qt.NoPen)
            pixPainter.setCompositionMode(QPainter.CompositionMode_Clear)
            new_pen_point = self.backgrounderaser_pointlist.pop(0)
            if self.old_pen is None:
                self.old_pen = new_pen_point
                continue
            if self.old_pen[0] != -2 and new_pen_point[0] != -2:
                pixPainter.drawEllipse(new_pen_point[0] - self.tool_width / 2,
                                       new_pen_point[1] - self.tool_width / 2,
                                       self.tool_width, self.tool_width)
                if abs(new_pen_point[0] - self.old_pen[0]) > 3 or abs(
                        new_pen_point[1] - self.old_pen[1]) > 3:
                    interpolateposs = get_line_interpolation(new_pen_point[:], self.old_pen[:])
                    if interpolateposs is not None:
                        for pos in interpolateposs:
                            x, y = pos
                            pixPainter.drawEllipse(x - self.tool_width / 2,
                                                   y - self.tool_width / 2,
                                                   self.tool_width, self.tool_width)

            self.old_pen = new_pen_point

        while len(self.repairbackground_pointlist):  # 背景修复画笔有值
            brush = QBrush(self.pencolor)

            brush.setTexture(self.originalPix)
            pixPainter.setBrush(brush)
            pixPainter.setPen(Qt.NoPen)
            new_pen_point = self.repairbackground_pointlist.pop(0)
            if self.old_pen is None:
                self.old_pen = new_pen_point
                continue
            if self.old_pen[0] != -2 and new_pen_point[0] != -2:
                pixPainter.drawEllipse(new_pen_point[0] - self.tool_width / 2,
                                       new_pen_point[1] - self.tool_width / 2,
                                       self.tool_width, self.tool_width)
                if abs(new_pen_point[0] - self.old_pen[0]) > 1 or abs(
                        new_pen_point[1] - self.old_pen[1]) > 1:
                    interpolateposs = get_line_interpolation(new_pen_point[:], self.old_pen[:])
                    if interpolateposs is not None:
                        for pos in interpolateposs:
                            x, y = pos
                            pixPainter.drawEllipse(x - self.tool_width / 2,
                                                   y - self.tool_width / 2,
                                                   self.tool_width, self.tool_width)

            self.old_pen = new_pen_point
        pixPainter.end()