import gc
import math
import os
import re
import sys
import time
import cv2

from numpy import array, zeros, uint8, float32,array
from PyQt5.QtGui import QCursor, QBrush, QScreen,QWindow
from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl
from PyQt5.QtGui import QPixmap, QPainter, QPen, QIcon, QFont, QImage, QColor
from PyQt5.QtCore import QPoint, QRectF, QMimeData

def get_opposite_color(color: QColor):
    return QColor(255 - color.red(), 255 - color.green(), 255 - color.blue())

class MaskLayer(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setMouseTracking(True)

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.parent.on_init:
            print('oninit return')
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        if self.parent.painter_tools["perspective_cut_on"]:  # 透视裁剪工具
            # painter.setPen(QPen(self.parent.pencolor, 3, Qt.SolidLine))
            color = get_opposite_color(self.parent.pencolor)
            for i in range(len(self.parent.perspective_cut_pointlist)):
                painter.setPen(QPen(color, 10, Qt.SolidLine))
                painter.drawPoint(QPoint(self.parent.perspective_cut_pointlist[i][0], self.parent.perspective_cut_pointlist[i][1]))
                painter.setPen(QPen(color, 3, Qt.SolidLine))
                if i < len(self.parent.perspective_cut_pointlist) - 1:
                    painter.drawLine(self.parent.perspective_cut_pointlist[i][0],
                                     self.parent.perspective_cut_pointlist[i][1],
                                     self.parent.perspective_cut_pointlist[i + 1][0],
                                     self.parent.perspective_cut_pointlist[i + 1][1])
                else:
                    painter.drawLine(self.parent.perspective_cut_pointlist[i][0],
                                     self.parent.perspective_cut_pointlist[i][1],
                                     self.parent.mouse_posx, self.parent.mouse_posy)
                    painter.drawLine(self.parent.perspective_cut_pointlist[0][0],
                                     self.parent.perspective_cut_pointlist[0][1],
                                     self.parent.mouse_posx, self.parent.mouse_posy)
            # 画网格
            painter.setPen(QPen(QColor(120, 180, 120, 180), 1, Qt.SolidLine))
            if len(self.parent.perspective_cut_pointlist) >= 2:
                p0 = self.parent.perspective_cut_pointlist[0]
                p1 = self.parent.perspective_cut_pointlist[1]
                pp1 = pp0 = (self.parent.mouse_posx, self.parent.mouse_posy)
                if len(self.parent.perspective_cut_pointlist) > 2:
                    pp1 = self.parent.perspective_cut_pointlist[2]
                dx1 = pp1[0] - p1[0]
                dy1 = pp1[1] - p1[1]
                dx0 = pp0[0] - p0[0]
                dy0 = pp0[1] - p0[1]
                maxs = max(math.sqrt(dy0 ** 2 + dx0 ** 2), math.sqrt(dy1 ** 2 + dx1 ** 2))
                if maxs > 25:
                    n = maxs // 25
                    ddx0 = dx0 / (n + 1)
                    ddy0 = dy0 / (n + 1)
                    ddx1 = dx1 / (n + 1)
                    ddy1 = dy1 / (n + 1)
                    for i in range(int(n) + 1):
                        painter.drawLine(pp0[0] - i * ddx0, pp0[1] - i * ddy0, pp1[0] - i * ddx1, pp1[1] - i * ddy1)
            if len(self.parent.perspective_cut_pointlist) >= 3:
                p0 = self.parent.perspective_cut_pointlist[1]
                p1 = self.parent.perspective_cut_pointlist[2]
                pp1 = (self.parent.mouse_posx, self.parent.mouse_posy)
                pp0 = self.parent.perspective_cut_pointlist[0]

                dx1 = pp1[0] - p1[0]
                dy1 = pp1[1] - p1[1]
                dx0 = pp0[0] - p0[0]
                dy0 = pp0[1] - p0[1]
                maxs = max(math.sqrt(dy0 ** 2 + dx0 ** 2), math.sqrt(dy1 ** 2 + dx1 ** 2))
                if maxs > 25:
                    n = maxs // 25
                    ddx0 = dx0 / (n + 1)
                    ddy0 = dy0 / (n + 1)
                    ddx1 = dx1 / (n + 1)
                    ddy1 = dy1 / (n + 1)
                    for i in range(int(n) + 1):
                        painter.drawLine(pp0[0] - i * ddx0, pp0[1] - i * ddy0, pp1[0] - i * ddx1, pp1[1] - i * ddy1)

        elif self.parent.painter_tools["polygon_ss_on"]:  # 多边形截图
            color = get_opposite_color(self.parent.pencolor)
            for i in range(len(self.parent.polygon_ss_pointlist)):
                painter.setPen(QPen(color, 3, Qt.SolidLine))
                if i < len(self.parent.polygon_ss_pointlist) - 1:
                    painter.drawLine(self.parent.polygon_ss_pointlist[i][0],
                                     self.parent.polygon_ss_pointlist[i][1],
                                     self.parent.polygon_ss_pointlist[i + 1][0],
                                     self.parent.polygon_ss_pointlist[i + 1][1])
                else:

                    painter.drawLine(self.parent.polygon_ss_pointlist[i][0],
                                     self.parent.polygon_ss_pointlist[i][1],
                                     self.parent.mouse_posx, self.parent.mouse_posy)
                    painter.setPen(QPen(QColor(200, 200, 200, 222), 2, Qt.DashDotLine))
                    painter.drawLine(self.parent.polygon_ss_pointlist[0][0],
                                     self.parent.polygon_ss_pointlist[0][1],
                                     self.parent.mouse_posx, self.parent.mouse_posy)

        elif not (self.parent.painter_tools['selectcolor_on'] or self.parent.painter_tools['bucketpainter_on']):
            # 正常显示选区
            rect = QRect(min(self.parent.x0, self.parent.x1), min(self.parent.y0, self.parent.y1),
                         abs(self.parent.x1 - self.parent.x0), abs(self.parent.y1 - self.parent.y0))

            painter.setPen(QPen(Qt.green, 2, Qt.SolidLine))
            painter.drawRect(rect)
            painter.drawRect(0, 0, self.width(), self.height())
            painter.setPen(QPen(QColor(0, 150, 0), 8, Qt.SolidLine))
            painter.drawPoint(
                QPoint(self.parent.x0, min(self.parent.y1, self.parent.y0) + abs(self.parent.y1 - self.parent.y0) // 2))
            painter.drawPoint(
                QPoint(min(self.parent.x1, self.parent.x0) + abs(self.parent.x1 - self.parent.x0) // 2, self.parent.y0))
            painter.drawPoint(
                QPoint(self.parent.x1, min(self.parent.y1, self.parent.y0) + abs(self.parent.y1 - self.parent.y0) // 2))
            painter.drawPoint(
                QPoint(min(self.parent.x1, self.parent.x0) + abs(self.parent.x1 - self.parent.x0) // 2, self.parent.y1))
            painter.drawPoint(QPoint(self.parent.x0, self.parent.y0))
            painter.drawPoint(QPoint(self.parent.x0, self.parent.y1))
            painter.drawPoint(QPoint(self.parent.x1, self.parent.y0))
            painter.drawPoint(QPoint(self.parent.x1, self.parent.y1))

            x = y = 100
            if self.parent.x1 > self.parent.x0:
                x = self.parent.x0 + 5
            else:
                x = self.parent.x0 - 72
            if self.parent.y1 > self.parent.y0:
                y = self.parent.y0 + 15
            else:
                y = self.parent.y0 - 5
            painter.setPen(QPen(Qt.darkGreen, 2, Qt.SolidLine))
            painter.drawText(x, y,
                             '{}x{}'.format(abs(self.parent.x1 - self.parent.x0), abs(self.parent.y1 - self.parent.y0)))

            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(0, 0, 0, 120))
            painter.drawRect(0, 0, self.width(), min(self.parent.y1, self.parent.y0))
            painter.drawRect(0, min(self.parent.y1, self.parent.y0), min(self.parent.x1, self.parent.x0),
                             self.height() - min(self.parent.y1, self.parent.y0))
            painter.drawRect(max(self.parent.x1, self.parent.x0), min(self.parent.y1, self.parent.y0),
                             self.width() - max(self.parent.x1, self.parent.x0),
                             self.height() - min(self.parent.y1, self.parent.y0))
            painter.drawRect(min(self.parent.x1, self.parent.x0), max(self.parent.y1, self.parent.y0),
                             max(self.parent.x1, self.parent.x0) - min(self.parent.x1, self.parent.x0),
                             self.height() - max(self.parent.y1, self.parent.y0))
        # 以下为鼠标放大镜
        if not (self.parent.painter_tools['drawcircle_on'] or self.parent.painter_tools['drawrect_bs_on'] or
                self.parent.painter_tools['pen_on'] or self.parent.painter_tools['eraser_on'] or
                self.parent.painter_tools['drawtext_on'] or self.parent.painter_tools['backgrounderaser_on']
                or self.parent.painter_tools['drawpix_bs_on'] or self.parent.move_rect):
            
            select_color_mode = True if self.parent.painter_tools['selectcolor_on'] or self.parent.painter_tools['bucketpainter_on'] else False  # 取色器或油漆桶
            
            if self.parent.mouse_posx > self.width() - 140:
                enlarge_box_x = self.parent.mouse_posx - 140
            else:
                enlarge_box_x = self.parent.mouse_posx + 20
            if self.parent.mouse_posy > self.height() - 140:
                enlarge_box_y = self.parent.mouse_posy - 120
            else:
                enlarge_box_y = self.parent.mouse_posy + 20
            enlarge_rect = QRect(enlarge_box_x, enlarge_box_y, 120, 120)
            painter.setPen(QPen(QColor(Qt.green), 1, Qt.SolidLine))
            painter.drawRect(enlarge_rect)
            painter.setBrush(QBrush(QColor(80, 80, 80, 180)))
            painter.drawRect(QRect(enlarge_box_x, enlarge_box_y-43, enlarge_rect.width(), 43))
            painter.setBrush(Qt.NoBrush)
            # painter.drawRect(QRect(enlarge_box_x, enlarge_box_y-42, enlarge_rect.width(), 42))
            color = QColor(self.parent.qimg.pixelColor(self.parent.mouse_posx, self.parent.mouse_posy))
            RGB_color = [color.red(), color.green(), color.blue()]
            HSV_color = cv2.cvtColor(array([[RGB_color]], dtype=uint8),cv2.COLOR_RGB2HSV).tolist()[0][0]
            painter.drawText(enlarge_box_x, enlarge_box_y - 6,' POS:({},{}) {}'.format(self.parent.mouse_posx, self.parent.mouse_posy,color.name().upper()if select_color_mode else ""))
            painter.drawText(enlarge_box_x, enlarge_box_y - 18," HSV:({},{},{})".format(HSV_color[0], HSV_color[1], HSV_color[2]))
            painter.drawText(enlarge_box_x, enlarge_box_y - 30," RGB:({},{},{})".format(RGB_color[0],RGB_color[1],RGB_color[2]))

            if select_color_mode:
                painter.setBrush(QBrush(color))
                painter.drawRect(QRect(enlarge_box_x - 20, enlarge_box_y, 20, 20))
                painter.setBrush(Qt.NoBrush)

            try:  # 鼠标放大镜
                painter.setCompositionMode(QPainter.CompositionMode_Source)
                rpix = QPixmap(self.width() + 120, self.height() + 120)
                rpix.fill(QColor(0, 0, 0))
                rpixpainter = QPainter(rpix)
                rpixpainter.drawPixmap(60, 60, self.parent.pixmap())
                rpixpainter.end()
                larger_pix = rpix.copy(self.parent.mouse_posx, self.parent.mouse_posy, 120, 120).scaled(120 + self.parent.tool_width * 10, 120 + self.parent.tool_width * 10)
                pix = larger_pix.copy(larger_pix.width() // 2 - 60, larger_pix.height() // 2 - 60, 120, 120)
                painter.drawPixmap(enlarge_box_x, enlarge_box_y, pix)
                painter.setPen(QPen(Qt.green, 1, Qt.SolidLine))
                painter.drawLine(enlarge_box_x, enlarge_box_y + 60, enlarge_box_x + 120, enlarge_box_y + 60)
                painter.drawLine(enlarge_box_x + 60, enlarge_box_y, enlarge_box_x + 60, enlarge_box_y + 120)
            except:
                print('draw_enlarge_box fail')
        painter.end()