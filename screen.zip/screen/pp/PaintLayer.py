import math
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl
from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtGui import QPixmap, QPainter, QPen, QIcon, QFont, QImage, QColor
from PyQt5.QtCore import QPoint, QRectF, QMimeData
from PyQt5.QtGui import QCursor, QBrush, QScreen,QWindow

def get_line_interpolation(p1, p2):  # 线性插值
    res = []
    dy = p1[1] - p2[1]
    dx = p1[0] - p2[0]
    n = max(abs(dy), abs(dx))
    nx = dx / n
    ny = dy / n
    for i in range(n):
        res.append([p2[0] + i * nx, p2[1] + i * ny])
    return res

class PaintLayer(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        # self.setAutoFillBackground(False)
        # self.setPixmap(QPixmap())
        self.setMouseTracking(True)
        self.px = self.py = -50
        self.pixpng = QPixmap(":/msk.jpg")

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.parent.on_init:
            print('oninit return')
            return
        if 1 in self.parent.painter_tools.values():  # 如果有画笔工具打开
            painter = QPainter(self)
            color = QColor(self.parent.pencolor)
            color.setAlpha(255)

            width = self.parent.tool_width
            if self.parent.painter_tools['selectcolor_on'] or self.parent.painter_tools['bucketpainter_on']:
                width = 5
                color = QColor(Qt.white)
            painter.setPen(QPen(color, 1, Qt.SolidLine))
            rect = QRectF(self.px - width // 2, self.py - width // 2,
                          width, width)
            painter.drawEllipse(rect)  # 画鼠标圆
            painter.end()
        # self.pixPainter.begin()
        try:
            self.pixPainter = QPainter(self.pixmap())
            self.pixPainter.setRenderHint(QPainter.Antialiasing)
        except:
            print('pixpainter fail!')
        while len(self.parent.eraser_pointlist):  # 橡皮擦工具
            # self.pixPainter.setRenderHint(QPainter.Antialiasing)
            self.pixPainter.setBrush(QColor(0, 0, 0, 0))
            self.pixPainter.setPen(Qt.NoPen)
            self.pixPainter.setCompositionMode(QPainter.CompositionMode_Clear)
            new_pen_point = self.parent.eraser_pointlist.pop(0)
            if self.parent.old_pen is None:
                self.parent.old_pen = new_pen_point
                continue
            if self.parent.old_pen[0] != -2 and new_pen_point[0] != -2:
                self.pixPainter.drawEllipse(new_pen_point[0] - self.parent.tool_width / 2,
                                            new_pen_point[1] - self.parent.tool_width / 2,
                                            self.parent.tool_width, self.parent.tool_width)
                if abs(new_pen_point[0] - self.parent.old_pen[0]) > 1 or abs(
                        new_pen_point[1] - self.parent.old_pen[1]) > 1:
                    interpolateposs = get_line_interpolation(new_pen_point[:], self.parent.old_pen[:])
                    if interpolateposs is not None:
                        for pos in interpolateposs:
                            x, y = pos
                            self.pixPainter.drawEllipse(x - self.parent.tool_width / 2,
                                                        y - self.parent.tool_width / 2,
                                                        self.parent.tool_width, self.parent.tool_width)

            self.parent.old_pen = new_pen_point

        def get_ture_pen_alpha_color():
            color = QColor(self.parent.pencolor)
            if color.alpha() != 255:
                al = self.parent.pencolor.alpha() / (self.parent.tool_width / 2)
                if al > 1:
                    color.setAlpha(al)
                else:
                    color.setAlpha(1)
            return color

        while len(self.parent.pen_pointlist):  # 画笔工具
            color = get_ture_pen_alpha_color()
            self.pixPainter.setBrush(color)
            self.pixPainter.setPen(Qt.NoPen)
            # self.pixPainter.setPen(QPen(self.parent.pencolor, self.parent.tool_width, Qt.SolidLine))
            self.pixPainter.setRenderHint(QPainter.Antialiasing)
            new_pen_point = self.parent.pen_pointlist.pop(0)
            if self.parent.old_pen is None:
                self.parent.old_pen = new_pen_point
                continue
            if self.parent.old_pen[0] != -2 and new_pen_point[0] != -2:
                self.pixPainter.drawEllipse(new_pen_point[0] - self.parent.tool_width / 2,
                                            new_pen_point[1] - self.parent.tool_width / 2,
                                            self.parent.tool_width, self.parent.tool_width)
                if abs(new_pen_point[0] - self.parent.old_pen[0]) > 1 or abs(
                        new_pen_point[1] - self.parent.old_pen[1]) > 1:
                    interpolateposs = get_line_interpolation(new_pen_point[:], self.parent.old_pen[:])
                    if interpolateposs is not None:
                        for pos in interpolateposs:
                            x, y = pos
                            self.pixPainter.drawEllipse(x - self.parent.tool_width / 2,
                                                        y - self.parent.tool_width / 2,
                                                        self.parent.tool_width, self.parent.tool_width)

            self.parent.old_pen = new_pen_point
        while len(self.parent.drawpix_pointlist):  # 贴图工具
            brush = QBrush(self.parent.pencolor)
            tpix = QPixmap(self.parent.tool_width, self.parent.tool_width)
            tpix.fill(Qt.transparent)
            tpixpainter = QPainter(tpix)
            tpixpainter.setCompositionMode(QPainter.CompositionMode_Source)
            tpixpainter.drawPixmap(0, 0, self.pixpng.scaled(self.parent.tool_width, self.parent.tool_width))
            tpixpainter.setCompositionMode(QPainter.CompositionMode_DestinationIn)
            if self.parent.pencolor.alpha() != 255:
                al = self.parent.pencolor.alpha() / (self.parent.tool_width / 2)
            else:
                al = 255
            tpixpainter.fillRect(tpix.rect(), QColor(0, 0, 0, al))
            tpixpainter.end()
            brush.setTexture(tpix)
            self.pixPainter.setBrush(brush)
            self.pixPainter.setPen(Qt.NoPen)
            new_pen_point = self.parent.drawpix_pointlist.pop(0)
            if self.parent.old_pen is None:
                self.parent.old_pen = new_pen_point
                continue
            if self.parent.old_pen[0] != -2 and new_pen_point[0] != -2:
                self.pixPainter.drawEllipse(new_pen_point[0] - self.parent.tool_width / 2,
                                            new_pen_point[1] - self.parent.tool_width / 2,
                                            self.parent.tool_width, self.parent.tool_width)
                if abs(new_pen_point[0] - self.parent.old_pen[0]) > 1 or abs(
                        new_pen_point[1] - self.parent.old_pen[1]) > 1:
                    interpolateposs = get_line_interpolation(new_pen_point[:], self.parent.old_pen[:])
                    if interpolateposs is not None:
                        for pos in interpolateposs:
                            x, y = pos
                            self.pixPainter.drawEllipse(x - self.parent.tool_width / 2,
                                                        y - self.parent.tool_width / 2,
                                                        self.parent.tool_width, self.parent.tool_width)

            self.parent.old_pen = new_pen_point
        if self.parent.drawrect_pointlist[0][0] != -2 and self.parent.drawrect_pointlist[1][0] != -2:  # 画矩形工具
            # print(self.parent.drawrect_pointlist)
            temppainter = QPainter(self)
            temppainter.setPen(QPen(self.parent.pencolor, self.parent.tool_width, Qt.SolidLine))

            poitlist = self.parent.drawrect_pointlist
            temppainter.drawRect(min(poitlist[0][0], poitlist[1][0]), min(poitlist[0][1], poitlist[1][1]),
                                 abs(poitlist[0][0] - poitlist[1][0]), abs(poitlist[0][1] - poitlist[1][1]))
            temppainter.end()
            if self.parent.drawrect_pointlist[2] == 1:
                self.pixPainter.setPen(QPen(self.parent.pencolor, self.parent.tool_width, Qt.SolidLine))
                self.pixPainter.drawRect(min(poitlist[0][0], poitlist[1][0]), min(poitlist[0][1], poitlist[1][1]),
                                         abs(poitlist[0][0] - poitlist[1][0]), abs(poitlist[0][1] - poitlist[1][1]))

                self.parent.drawrect_pointlist = [[-2, -2], [-2, -2], 0]
                # print("panit",self.parent.drawrect_pointlist)
                # self.parent.drawrect_pointlist[0] = [-2, -2]

        if self.parent.drawcircle_pointlist[0][0] != -2 and self.parent.drawcircle_pointlist[1][0] != -2:  # 画圆工具
            temppainter = QPainter(self)
            temppainter.setPen(QPen(self.parent.pencolor, self.parent.tool_width, Qt.SolidLine))
            poitlist = self.parent.drawcircle_pointlist
            temppainter.drawEllipse(min(poitlist[0][0], poitlist[1][0]), min(poitlist[0][1], poitlist[1][1]),
                                    abs(poitlist[0][0] - poitlist[1][0]), abs(poitlist[0][1] - poitlist[1][1]))
            temppainter.end()
            if self.parent.drawcircle_pointlist[2] == 1:
                self.pixPainter.setPen(QPen(self.parent.pencolor, self.parent.tool_width, Qt.SolidLine))
                self.pixPainter.drawEllipse(min(poitlist[0][0], poitlist[1][0]), min(poitlist[0][1], poitlist[1][1]),
                                            abs(poitlist[0][0] - poitlist[1][0]), abs(poitlist[0][1] - poitlist[1][1]))
                self.parent.drawcircle_pointlist = [[-2, -2], [-2, -2], 0]
                # self.parent.drawcircle_pointlist[0] = [-2, -2]

        if self.parent.drawarrow_pointlist[0][0] != -2 and self.parent.drawarrow_pointlist[1][0] != -2:  # 画箭头
            # print(self.parent.drawarrow_pointlist)
            # self.pixPainter = QPainter(self.pixmap())
            temppainter = QPainter(self)
            # temppainter.setPen(QPen(self.parent.pencolor, 3, Qt.SolidLine))
            # brush = QBrush(self.parent.pencolor)
            # brush.setTexture(QPixmap(":/msk.jpg").scaled(225, 225))
            # temppainter.setBrush(brush)
            poitlist = self.parent.drawarrow_pointlist
            temppainter.translate(poitlist[0][0], poitlist[0][1])
            degree = math.degrees(math.atan2(poitlist[1][1] - poitlist[0][1], poitlist[1][0] - poitlist[0][0]))
            temppainter.rotate(degree)
            dx = math.sqrt((poitlist[1][1] - poitlist[0][1]) ** 2 + (poitlist[1][0] - poitlist[0][0]) ** 2)
            dy = 30
            temppainter.drawPixmap(0, -dy / 2, QPixmap(':/arrow.png').scaled(dx, dy))

            temppainter.end()
            if self.parent.drawarrow_pointlist[2] == 1:
                self.pixPainter.translate(poitlist[0][0], poitlist[0][1])
                degree = math.degrees(math.atan2(poitlist[1][1] - poitlist[0][1], poitlist[1][0] - poitlist[0][0]))
                self.pixPainter.rotate(degree)
                dx = math.sqrt((poitlist[1][1] - poitlist[0][1]) ** 2 + (poitlist[1][0] - poitlist[0][0]) ** 2)
                dy = 30
                self.pixPainter.drawPixmap(0, -dy / 2, QPixmap(':/arrow.png').scaled(dx, dy))
                self.parent.drawarrow_pointlist = [[-2, -2], [-2, -2], 0]
                # self.parent.drawarrow_pointlist[0] = [-2, -2]

        if len(self.parent.drawtext_pointlist) > 1 or self.parent.text_box.paint:  # 绘制文字
            self.parent.text_box.paint = False
            # print(self.parent.drawtext_pointlist)
            text = self.parent.text_box.toPlainText()
            self.parent.text_box.clear()
            pos = self.parent.drawtext_pointlist.pop(0)
            if text:
                self.pixPainter.setFont(QFont('', self.parent.tool_width))
                self.pixPainter.setPen(QPen(self.parent.pencolor, 3, Qt.SolidLine))
                self.pixPainter.drawText(pos[0] + self.parent.text_box.document.size().height() / 8,
                                         pos[1] + self.parent.text_box.document.size().height() * 32 / 41, text)
                self.parent.backup_shortshot()
                self.parent.setFocus()
                self.update()
                # self.repaint()
        try:
            self.pixPainter.end()
        except:
            print("pixpainter end fail!")