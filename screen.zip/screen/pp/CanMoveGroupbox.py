from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl

class CanMoveGroupbox(QGroupBox):  # 移动groupbox
    def __init__(self, parent):
        super(CanMoveGroupbox, self).__init__(parent)
        self.drag = False
        self.p_x, self.p_y = 0, 0

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and event.x() < 100:
            self.setCursor(Qt.SizeAllCursor)
            self.drag = True
            self.p_x, self.p_y = event.x(), event.y()
        # super(CanMoveGroupbox, self).mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.setCursor(Qt.ArrowCursor)
            self.drag = False
        # super(CanMoveGroupbox, self).mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
        if self.isVisible():
            if self.drag:
                self.move(event.x() + self.x() - self.p_x, event.y() + self.y() - self.p_y)

        # super(CanMoveGroupbox, self).mouseMoveEvent(event)