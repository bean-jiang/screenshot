from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl

class HoverButton(QPushButton):
    hoversignal = pyqtSignal(int)

    def enterEvent(self, e) -> None:
        super(HoverButton, self).enterEvent(e)
        self.hoversignal.emit(1)
        print("enter")

    def leaveEvent(self, e):
        super(HoverButton, self).leaveEvent(e)
        # time.sleep(2)
        self.hoversignal.emit(0)
        print("leave")