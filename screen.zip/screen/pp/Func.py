from PyQt5.QtWidgets import QApplication 
from pynput.mouse import Controller
from numpy import array, zeros, uint8, float32,array
import math
import cv2

def search_in_which_screen():
    mousepos     = Controller().position
    screens      = QApplication.screens()
    secondscreen = QApplication.primaryScreen()
    for i in screens:
        rect = i.geometry().getRect()
        posX = (int)(mousepos[0])
        posY = (int)(mousepos[1])
        if (posX in range(rect[0],rect[0]+rect[2])) and (posY in range(rect[1],rect[1]+rect[3])):
            secondscreen = i
            break
    return secondscreen

def cut_polypng(img, pointlist):  # 多边形裁剪
    xlist = [i[0] for i in pointlist]
    ylist = [i[1] for i in pointlist]
    w = max(xlist) - min(xlist)
    h = max(ylist) - min(ylist)
    x0, y0 = min(xlist), min(ylist)
    for i, lis in enumerate(pointlist):
        pointlist[i] = [lis[0] - x0, lis[1] - y0]
    img = img[y0:y0 + h, x0:x0 + w]
    pts = array(pointlist)
    pts = array([pts])
    # 和原始图像一样大小的0矩阵，作为mask
    mask = zeros(img.shape[:2], uint8)
    # 在mask上将多边形区域填充为白色
    cv2.polylines(mask, pts, 1, 255)  # 描绘边缘
    cv2.fillPoly(mask, pts, 255)  # 填充
    # 逐位与，得到裁剪后图像，此时是黑色背景
    dstimg = cv2.bitwise_and(img, img, mask=mask)
    return dstimg

def image_fill(image, x, y, color: tuple = (0, 0, 255), d=0):  # 泛洪填充
    src = image.copy()  # 先创建一个副本
    cv2.floodFill(src, None, (x, y), color, (d, d, d), (d, d, d), cv2.FLOODFILL_FIXED_RANGE)
    # cv2.circle(src, (x, y), 2, color=(0, 255, 0), thickness=4)
    # cv2.imshow('flood_fill', src)
    return src

def cut_mutipic(img, pointlist):  # 透视裁剪
    xlist = [i[0] for i in pointlist]
    ylist = [i[1] for i in pointlist]
    w = max(xlist) - min(xlist)
    h = max(ylist) - min(ylist)
    bl = w / abs(pointlist[0][0] - pointlist[1][0])
    x0, y0 = min(xlist), min(ylist)
    for i, lis in enumerate(pointlist):
        pointlist[i] = [lis[0] - x0, lis[1] - y0]
    img = img[y0:y0 + h, x0:x0 + w]
    pts = array(pointlist)
    pts = array([pts])
    # 和原始图像一样大小的0矩阵，作为mask
    mask = zeros(img.shape[:2], uint8)
    # 在mask上将多边形区域填充为白色
    cv2.polylines(mask, pts, 1, 255)  # 描绘边缘
    cv2.fillPoly(mask, pts, 255)  # 填充
    # 逐位与，得到裁剪后图像，此时是黑色背景
    dstimg = cv2.bitwise_and(img, img, mask=mask)
    # cv2.imshow("dst", dst)
    tw = max(math.sqrt((pointlist[0][1] - pointlist[3][1]) ** 2 + (pointlist[0][0] - pointlist[3][0]) ** 2),
             math.sqrt((pointlist[1][1] - pointlist[2][1]) ** 2 + (pointlist[1][0] - pointlist[2][0]) ** 2))
    th = max(math.sqrt((pointlist[0][1] - pointlist[3][1]) ** 2 + (pointlist[0][0] - pointlist[3][0]) ** 2),
             math.sqrt((pointlist[2][1] - pointlist[1][1]) ** 2 + (pointlist[2][0] - pointlist[1][0]) ** 2),
             h)
    # if bl>1:
    #     th=th*bl
    tw, th = int(tw), int(th)
    org = array(pointlist, float32)
    dst = array([[0, 0],
                 [tw, 0],
                 [tw, th],
                 [0, th]], float32)
    warpR = cv2.getPerspectiveTransform(org, dst)
    result = cv2.warpPerspective(dstimg, warpR, (tw, th), borderMode=cv2.BORDER_TRANSPARENT)
    # cv2.namedWindow("result",0)
    # cv2.imshow("result", result)
    # cv2.waitKey(0)
    return result

def get_line_interpolation(p1, p2):  # 线性插值
    res = []
    dy = p1[1] - p2[1]
    dx = p1[0] - p2[0]
    n = max(abs(dy), abs(dx))
    nx = dx / n
    ny = dy / n
    for i in range(n):
        res.append([p2[0] + i * nx, p2[1] + i * ny])
    return res