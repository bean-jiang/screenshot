from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl

class AutotextEdit(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.document = self.document()
        self.document.contentsChanged.connect(self.textAreaChanged)
        self.setLineWrapMode(QTextEdit.NoWrap)
        self.paint = False
        self.parent = parent

    def textAreaChanged(self, minsize=0):
        self.document.adjustSize()
        newWidth  = (int)(self.document.size().width() + 25)
        newHeight = (int)(self.document.size().height() + 15)
        
        if newWidth != self.width():
            if newWidth < minsize:
                self.setFixedWidth(minsize)
            else:
                self.setFixedWidth(newWidth)
        if newHeight != self.height():
            if newHeight < minsize:
                self.setFixedHeight(minsize)
            else:
                self.setFixedHeight(newHeight)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Return:
            self.paint = True
            self.hide()
        super().keyPressEvent(e)

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key_Return:
            self.parent.update()
        super().keyReleaseEvent(e)