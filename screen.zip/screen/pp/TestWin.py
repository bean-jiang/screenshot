import gc
import math
import os
import re
import sys
import time
from PyQt5.QtWidgets import QWidget,QApplication,QPushButton
from pp.Slabel import Slabel


class TestWin(QWidget):
    def __init__(self):
        super(TestWin,self).__init__()
        # 储存固定截屏在屏幕上的数组
        self.freeze_imgs = []
        btn = QPushButton("截屏", self)
        btn.setGeometry(20, 20, 60, 30)
        btn.setShortcut("Commond+M")
        btn.clicked.connect(self.ss)
        self.temppos = [500, 100]
        self.s = Slabel(self)
        self.s.close_signal.connect(self.ss_end)  
        self.resize(100, 100)
    
    #截屏开始
    def ss(self):
        # 设置透明度而不是hide是因为透明度更快
        self.setWindowOpacity(0)
        self.temppos = [self.x(),self.y()]
        self.move(QApplication.desktop().width(),QApplication.desktop().height())
        self.s.screen_shot()
    

    def ss_end(self):
        del self.s
        self.move(self.temppos[0], self.temppos[1])
        self.show()
        self.setWindowOpacity(1)
        self.raise_()
        gc.collect()
        print(gc.isenabled(), gc.get_count(), gc.get_freeze_count())
        print('cleard')
        self.s = Slabel(self)
        self.s.close_signal.connect(self.ss_end)
    
    
    def show(self) -> None:
        super(TestWin, self).show()