from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl

class HoverGroupbox(QGroupBox):
    hoversignal = pyqtSignal(int)

    def enterEvent(self, e) -> None:
        super(HoverGroupbox, self).enterEvent(e)
        self.hoversignal.emit(1)
        print("enter")

    def leaveEvent(self, e):
        super(HoverGroupbox, self).leaveEvent(e)
        # time.sleep(2)
        self.hoversignal.emit(0)
        print("leave")