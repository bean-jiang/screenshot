from PyQt5.QtGui import QPixmap, QPainter, QPen, QIcon, QFont, QImage, QColor
from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QTextEdit, QFileDialog, QMenu, QGroupBox, QSpinBox, QWidget
from PyQt5.QtCore import QRect, Qt, pyqtSignal, QStandardPaths, QTimer, QSettings, QUrl

class ColorButton(QPushButton):
    select_color_signal = pyqtSignal(str)

    def __init__(self, color, parent):
        super(ColorButton, self).__init__("", parent)
        self.color = QColor(color).name()
        self.setStyleSheet("background-color:{}".format(self.color))
        self.clicked.connect(self.sendcolor)

    def sendcolor(self):
        self.select_color_signal.emit(self.color)